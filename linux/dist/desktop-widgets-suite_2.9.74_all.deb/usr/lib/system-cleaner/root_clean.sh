#!/bin/bash
# 需要管理员权限的清理动作（只接受白名单 key，不做任意路径删除）
set -u
case "${1:-}" in
  pkg-cache)
    apt-get clean >/dev/null 2>&1
    rm -f /var/cache/apt/archives/*.deb 2>/dev/null
    rm -rf /var/cache/apt/archives/partial/* 2>/dev/null
    ;;
  sys-log)
    journalctl --vacuum-time=7d >/dev/null 2>&1
    journalctl --vacuum-size=200M >/dev/null 2>&1
    rm -f /var/log/*.old /var/log/*.gz 2>/dev/null
    ;;
  tmp-old)
    find /tmp -maxdepth 1 -type f -mtime +7 -delete 2>/dev/null
    find /tmp -maxdepth 1 -type d -mtime +7 -empty -delete 2>/dev/null
    ;;
  docker-dangling)
    if command -v docker >/dev/null 2>&1; then
      docker image prune -f >/dev/null 2>&1
    fi
    ;;
  *)
    echo "未知清理项目: ${1:-}" >&2
    exit 1
    ;;
esac
exit 0
