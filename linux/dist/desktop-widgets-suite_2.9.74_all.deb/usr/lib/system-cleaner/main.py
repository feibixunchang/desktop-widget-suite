#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""系统垃圾清理（Deepin）
- 按项目勾选要清理的内容，显示每项占用空间
- 浏览器只清缓存，绝不动账号密码 / 书签 / Cookie
- 需要管理员权限的项目（apt 缓存、系统日志、/tmp 旧文件）通过授权执行
"""
import glob
import os
import shutil
import subprocess
import sys
import threading

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

APP = 'system-cleaner'
HOME = os.path.expanduser('~')
HELPER = '/usr/lib/%s/root_clean.sh' % APP

# 浏览器只删这些缓存子目录，配置/密码/书签/Cookie 一律不碰
CHROME_CACHES = ['Cache', 'Code Cache', 'GPUCache', 'GrShaderCache',
                 'ShaderCache', 'DawnCache', 'Service Worker/CacheStorage',
                 'Service Worker/ScriptCache']
BROWSER_PROFILES = [
    '~/.config/google-chrome/*',
    '~/.config/chromium/*',
    '~/.config/microsoft-edge/*',
    '~/.config/org.deepin.browser/*',
    '~/.config/deepin-browser/*',
    '~/.config/360browser/*',
    '~/.config/BraveSoftware/Brave-Browser/*',
]

ITEMS = [
    {'key': 'user-cache', 'name': '用户缓存（~/.cache）',
     'desc': '各类应用的临时缓存，删除后首次启动略慢，之后自动重建',
     'globs': ['~/.cache'], 'mode': 'content',
     'keep': ['~/.cache/system-cleaner'], 'root': False},
    {'key': 'thumbnails', 'name': '图片缩略图缓存',
     'desc': '文件管理器预览图缓存，会自动重建',
     'globs': ['~/.cache/thumbnails', '~/.thumbnails'],
     'mode': 'content', 'root': False},
    {'key': 'browser-cache', 'name': '浏览器缓存（不含密码/书签/登录状态）',
     'desc': 'Chrome / Edge / 深度浏览器等的网页缓存',
     'globs': [], 'mode': 'browser', 'root': False},
    {'key': 'firefox-cache', 'name': 'Firefox 缓存（不含密码/书签）',
     'desc': 'Firefox 网页缓存目录',
     'globs': ['~/.cache/mozilla/firefox/*/cache2'],
     'mode': 'content', 'root': False},
    {'key': 'trash', 'name': '回收站',
     'desc': '清空回收站（删除后不可恢复）',
     'globs': ['~/.local/share/Trash/files', '~/.local/share/Trash/info',
               '~/.local/share/Trash/expunged'],
     'mode': 'content', 'root': False},
    {'key': 'app-logs', 'name': '应用日志',
     'desc': '桌面挂件与本地应用的运行日志',
     'globs': ['~/.local/share/*/*.log', '~/.local/share/*/*.log.*',
               '~/.xsession-errors*', '~/.config/*/app.log'],
     'mode': 'glob', 'root': False},
    {'key': 'pkg-cache', 'name': '软件包缓存（需管理员）',
     'desc': '安装软件后残留的 .deb 安装包',
     'globs': [], 'mode': 'root', 'root': True},
    {'key': 'sys-log', 'name': '系统日志（需管理员）',
     'desc': '保留最近 7 天，更早的系统日志删除',
     'globs': [], 'mode': 'root', 'root': True},
    {'key': 'tmp-old', 'name': '临时文件（需管理员）',
     'desc': '删除 /tmp 中 7 天前的残留文件',
     'globs': [], 'mode': 'root', 'root': True},
    {'key': 'docker-dangling', 'name': 'Docker 悬空数据（需管理员）',
     'desc': '清理无用镜像层（不影响正在运行的容器）',
     'globs': [], 'mode': 'root', 'root': True},
]


def expand(path):
    return os.path.expanduser(path)


def dir_size(path):
    total = n = 0
    for root, dirs, files in os.walk(path, onerror=lambda e: None):
        for f in files:
            try:
                st = os.stat(os.path.join(root, f), follow_symlinks=False)
                total += st.st_size
                n += 1
            except OSError:
                pass
    return total, n


def human(size):
    size = float(size)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if size < 1024 or unit == 'TB':
            return ('%d B' % size) if unit == 'B' else ('%.1f %s' % (size, unit))
        size /= 1024.0


def browser_cache_dirs():
    out = []
    for pat in BROWSER_PROFILES:
        for prof in glob.glob(expand(pat)):
            for sub in CHROME_CACHES:
                d = os.path.join(prof, sub)
                if os.path.isdir(d):
                    out.append(d)
    return out


def sizes_for(item):
    total = n = 0
    if item['mode'] == 'browser':
        for d in browser_cache_dirs():
            s, c = dir_size(d)
            total += s
            n += c
        return total, n
    if item['mode'] == 'root':
        return root_size(item['key']), 0
    for pat in item['globs']:
        for p in glob.glob(expand(pat)):
            if os.path.isdir(p) and not os.path.islink(p):
                s, c = dir_size(p)
                total += s
                n += c
            elif os.path.isfile(p):
                try:
                    total += os.path.getsize(p)
                    n += 1
                except OSError:
                    pass
    return total, n


def root_size(key):
    """需要权限的项目：用 du 估算（失败则返回 0）"""
    cmds = {
        'pkg-cache': "du -sb /var/cache/apt/archives 2>/dev/null | cut -f1",
        'sys-log': "du -sb /var/log/journal 2>/dev/null | cut -f1",
        'tmp-old': ("find /tmp -maxdepth 1 -type f -mtime +7 -printf '%s\\n' "
                    "2>/dev/null | awk '{s+=$1} END {print s+0}'"),
        'docker-dangling': "echo 0",
    }
    try:
        out = subprocess.run(['bash', '-c', cmds.get(key, 'echo 0')],
                             capture_output=True, text=True, timeout=25).stdout
        return int(float((out or '0').strip().splitlines()[-1] or 0))
    except Exception:
        return 0


def remove_path(p):
    try:
        if os.path.islink(p) or os.path.isfile(p):
            os.remove(p)
            return True
        shutil.rmtree(p, ignore_errors=True)
        return not os.path.exists(p)
    except Exception:
        return False


def clean_item(item):
    """清理一个项目，返回释放的字节数"""
    before, _ = sizes_for(item)
    if item['mode'] == 'root':
        try:
            subprocess.run(['pkexec', HELPER, item['key']], timeout=300)
        except Exception:
            pass
    elif item['mode'] == 'browser':
        for d in browser_cache_dirs():
            for entry in os.listdir(d) if os.path.isdir(d) else []:
                remove_path(os.path.join(d, entry))
    elif item['mode'] == 'content':
        keep = [expand(k) for k in item.get('keep', [])]
        for pat in item['globs']:
            for p in glob.glob(expand(pat)):
                if not os.path.isdir(p) or os.path.islink(p):
                    remove_path(p)
                    continue
                for entry in os.listdir(p):
                    full = os.path.join(p, entry)
                    if any(os.path.abspath(full) == os.path.abspath(k) for k in keep):
                        continue
                    remove_path(full)
    else:  # glob
        for pat in item['globs']:
            for p in glob.glob(expand(pat)):
                remove_path(p)
    after, _ = sizes_for(item)
    return max(0, before - after)


class CleanerWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title='系统垃圾清理')
        self.set_default_size(900, 820)
        self.set_border_width(12)
        self.set_icon_name(APP)
        self.rows = {}
        self.busy = False
        self._build()
        self.connect('destroy', Gtk.main_quit)

    def _fit_height(self):
        """按内容自动调整窗口高度，保证 10 个项目一次全部显示"""
        try:
            self.show_all()
            while Gtk.events_pending():
                Gtk.main_iteration_do(False)
            w = int(self.get_size()[0] or 900)
            # 关键: 必须按"当前宽度"计算高度. 用 get_preferred_height() 会按
            # 自然宽度(很宽)来算, 自动换行的说明文字被少算一行 -> 最后一项被截断
            need = self.box.get_preferred_height_for_width(w)[1] + 24
            try:
                mon = self.get_display().get_monitor_at_window(self.get_window())
                cap = max(420, mon.get_workarea().height - 60)
            except Exception:
                cap = 1400
            h = int(min(need, cap))
            if abs(self.get_size()[1] - h) > 2:
                self.resize(int(w), h)
        except Exception:
            pass

    def _build(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.box = box
        self.add(box)

        title = Gtk.Label()
        title.set_markup('<span size="x-large" weight="bold">🧹 系统垃圾清理</span>')
        title.set_halign(Gtk.Align.START)
        box.pack_start(title, False, False, 0)

        tip = Gtk.Label(label='勾选要清理的项目 → 点「立即清理」。'
                              '浏览器项目只清理网页缓存，账号密码、书签、登录状态不会动。')
        tip.set_line_wrap(True)
        tip.set_xalign(0)
        box.pack_start(tip, False, False, 0)

        sw = Gtk.ScrolledWindow()
        self.sw = sw
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_vexpand(True)
        sw.set_min_content_height(120)
        # 关键: 让滚动区的"自然高度"= 内容完整高度, 窗口据此一次显示全部项目
        try:
            sw.set_propagate_natural_height(True)
        except Exception:
            pass
        box.pack_start(sw, True, True, 0)
        listbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.listbox = listbox
        sw.add(listbox)

        for item in ITEMS:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            row.set_margin_top(2)
            row.set_margin_bottom(2)
            chk = Gtk.CheckButton()
            chk.set_active(not item['root'])
            chk.set_valign(Gtk.Align.START)
            row.pack_start(chk, False, False, 0)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
            name = Gtk.Label()
            name.set_markup('<b>%s</b>' % item['name'])
            name.set_xalign(0)
            desc = Gtk.Label(label=item['desc'])
            desc.set_xalign(0)
            desc.set_line_wrap(True)
            desc.get_style_context().add_class('dim-label')
            texts.pack_start(name, False, False, 0)
            texts.pack_start(desc, False, False, 0)
            row.pack_start(texts, True, True, 0)
            size = Gtk.Label(label='计算中…')
            size.set_width_chars(13)
            size.set_xalign(1)
            size.set_valign(Gtk.Align.CENTER)
            row.pack_start(size, False, False, 0)
            listbox.pack_start(row, False, False, 4)
            self.rows[item['key']] = (chk, size, item)

        btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        box.pack_start(btns, False, False, 0)
        self.all_btn = Gtk.Button(label='全选')
        self.all_btn.connect('clicked', self.on_all)
        btns.pack_start(self.all_btn, False, False, 0)
        self.none_btn = Gtk.Button(label='全不选')
        self.none_btn.connect('clicked', self.on_none)
        btns.pack_start(self.none_btn, False, False, 0)
        self.scan_btn = Gtk.Button(label='重新扫描')
        self.scan_btn.connect('clicked', lambda w: self.scan())
        btns.pack_start(self.scan_btn, False, False, 0)

        self.clean_btn = Gtk.Button(label='立即清理')
        self.clean_btn.get_style_context().add_class('suggested-action')
        self.clean_btn.connect('clicked', self.on_clean)
        btns.pack_end(self.clean_btn, False, False, 0)

        self.status = Gtk.Label(label='正在统计各项目占用…')
        self.status.set_xalign(0)
        box.pack_start(self.status, False, False, 0)
        self.scan()
        GLib.idle_add(self._fit_height)
        GLib.timeout_add(350, self._fit_height)
        GLib.timeout_add(900, self._fit_height)

    def on_all(self, w):
        for chk, _, _ in self.rows.values():
            chk.set_active(True)

    def on_none(self, w):
        for chk, _, _ in self.rows.values():
            chk.set_active(False)

    def _set_status(self, text):
        GLib.idle_add(self.status.set_text, text)

    def scan(self):
        if self.busy:
            return
        self.busy = True
        self.scan_btn.set_sensitive(False)

        def work():
            total = 0
            for key, (chk, label, item) in self.rows.items():
                s, n = sizes_for(item)
                total += s
                GLib.idle_add(label.set_text, '%s / %d 项' % (human(s), n))
            GLib.idle_add(self._scan_done, total)

        threading.Thread(target=work, daemon=True).start()

    def _scan_done(self, total):
        self.busy = False
        self.scan_btn.set_sensitive(True)
        self.status.set_text('可清理空间合计约 %s' % human(total))
        GLib.idle_add(self._fit_height)
        GLib.timeout_add(300, self._fit_height)

    def on_clean(self, w):
        if self.busy:
            return
        picked = [(k, item) for k, (chk, _, item) in self.rows.items()
                  if chk.get_active()]
        if not picked:
            self._info('请先勾选要清理的项目')
            return
        names = '\n'.join('· ' + i['name'] for _, i in picked)
        if not self._confirm('确认清理以下项目？\n\n%s\n\n'
                             '（回收站中的内容删除后不可恢复）' % names):
            return
        self.busy = True
        self.clean_btn.set_sensitive(False)
        self.scan_btn.set_sensitive(False)

        def work():
            freed = 0
            for key, item in picked:
                self._set_status('正在清理：%s …' % item['name'])
                freed += clean_item(item)
                GLib.idle_add(self.rows[key][0].set_active, False)
            GLib.idle_add(self._clean_done, freed)

        threading.Thread(target=work, daemon=True).start()

    def _clean_done(self, freed):
        self.busy = False
        self.clean_btn.set_sensitive(True)
        self.scan_btn.set_sensitive(True)
        self.scan()
        self.status.set_text('清理完成，共释放约 %s' % human(freed))
        GLib.idle_add(self._fit_height)

    def _info(self, text):
        d = Gtk.MessageDialog(transient_for=self, modal=True,
                              message_type=Gtk.MessageType.INFO,
                              buttons=Gtk.ButtonsType.OK, text=text)
        d.run()
        d.destroy()

    def _confirm(self, text):
        d = Gtk.MessageDialog(transient_for=self, modal=True,
                              message_type=Gtk.MessageType.QUESTION,
                              buttons=Gtk.ButtonsType.OK_CANCEL, text=text)
        ok = d.run() == Gtk.ResponseType.OK
        d.destroy()
        return ok


def main():
    win = CleanerWindow()
    win.show_all()
    Gtk.main()


if __name__ == '__main__':
    main()
