#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""划选复制工具条（Deepin）
- 按住左键划过文字后，在下方浮出工具条：复制 / 粘贴 / 剪切 / 全选 / 打开链接 /
  搜索 / 翻译 / 关闭
- 托盘图标常驻，可暂停启用
- 监听鼠标按键（evdev），读取 X11 主选区（primary selection）内容
"""
import cairo
import ctypes
import ctypes.util
import glob
import hashlib
import json
import os
import random
import re
import struct
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
try:
    gi.require_version('AyatanaAppIndicator3', '0.1')
    from gi.repository import AyatanaAppIndicator3 as AppIndicator
    HAVE_TRAY = True
except Exception:
    HAVE_TRAY = False
from gi.repository import Gtk, Gdk, GLib

APP = 'copy-toolbar'
HOME = os.path.expanduser('~')
CONF_DIR = os.path.join(HOME, '.config', APP)
CONF_PATH = os.path.join(CONF_DIR, 'config.json')
# 截图工具框选期间会创建这个标记文件
SHOT_FLAG = '/tmp/shot-ocr.capturing'

DEFAULTS = {
    'enabled': True,
    'min_distance': 14,       # 拖动多少像素才认为"划过"
    'min_interval': 0.12,     # 最短按住时间（秒）
    'hide_delay': 0,          # 0 = 不自动隐藏（点 ✕ 才关闭）
    'to_lang': 'zh',
    'backend': 'baidu',
    'baidu_appid': '20250205002265891',
    'baidu_key': 'IkK3ngwjhkS4lldTunex',
    'buttons': ['复制', '粘贴', '剪切', '全选', '打开链接', '搜索', '翻译'],
    'offset_y': 18,
}

# evdev 常量
EV_KEY, EV_REL = 1, 2
BTN_LEFT = 0x110
KEY_ESC = 1


def _parse_cap(path):
    """读取 sysfs capabilities 里的十六进制数值，如 '12001f'。"""
    with open(path) as f:
        s = f.read().strip()
    return int(s, 16)


def load_cfg():
    cfg = dict(DEFAULTS)
    try:
        with open(CONF_PATH) as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    return cfg


def save_cfg(cfg):
    try:
        os.makedirs(CONF_DIR, exist_ok=True)
        with open(CONF_PATH, 'w') as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ─────────────────── 鼠标位置（X11，无第三方依赖） ───────────────────

_libX11 = None


def _x11():
    global _libX11
    if _libX11 is None:
        lib = ctypes.CDLL(ctypes.util.find_library('X11'))
        lib.XOpenDisplay.restype = ctypes.c_void_p
        lib.XOpenDisplay.argtypes = [ctypes.c_char_p]
        lib.XDefaultRootWindow.restype = ctypes.c_ulong
        lib.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
        lib.XQueryPointer.argtypes = [ctypes.c_void_p, ctypes.c_ulong,
                                      ctypes.POINTER(ctypes.c_ulong),
                                      ctypes.POINTER(ctypes.c_ulong),
                                      ctypes.POINTER(ctypes.c_int),
                                      ctypes.POINTER(ctypes.c_int),
                                      ctypes.POINTER(ctypes.c_int),
                                      ctypes.POINTER(ctypes.c_int),
                                      ctypes.POINTER(ctypes.c_uint)]
        lib.XQueryPointer.restype = ctypes.c_int
        _libX11 = lib
    return _libX11


_dpy_cache = None


def _display():
    """复用同一个 X display 连接。

    XOpenDisplay 每次调用都会新建连接且不会自动释放；若不复用，
    每处理一次鼠标事件就泄漏一条连接，最终占满 X 客户端名额（256），
    导致其它程序再也打不开显示。
    """
    global _dpy_cache
    if _dpy_cache is None:
        _dpy_cache = _x11().XOpenDisplay(None)
    return _dpy_cache


def pointer_xy():
    try:
        lib = _x11()
        dpy = _display()
        if not dpy:
            return None, None
        root = lib.XDefaultRootWindow(dpy)
        rr = ctypes.c_ulong()
        cr = ctypes.c_ulong()
        rx = ctypes.c_int()
        ry = ctypes.c_int()
        wx = ctypes.c_int()
        wy = ctypes.c_int()
        mask = ctypes.c_uint()
        if not lib.XQueryPointer(dpy, root, ctypes.byref(rr), ctypes.byref(cr),
                                 ctypes.byref(rx), ctypes.byref(ry),
                                 ctypes.byref(wx), ctypes.byref(wy),
                                 ctypes.byref(mask)):
            return None, None
        return rx.value, ry.value
    except Exception:
        return None, None


# ─────────────────── 翻译（与截图工具同一套后端） ───────────────────

LANG_NAME = {'zh': '中文', 'en': '英文', 'ja': '日文', 'ko': '韩文',
             'fr': '法文', 'de': '德文', 'ru': '俄文', 'es': '西班牙文'}
BMAP = {'zh': 'zh', 'en': 'en', 'ja': 'jp', 'ko': 'kor', 'fr': 'fra',
        'de': 'de', 'ru': 'ru', 'es': 'spa'}
GMAP = {'zh': 'zh-CN', 'en': 'en', 'ja': 'ja', 'ko': 'ko', 'fr': 'fr',
        'de': 'de', 'ru': 'ru', 'es': 'es'}


def _http(url, data=None, timeout=15):
    req = urllib.request.Request(
        url, data=data,
        headers={'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) copy-toolbar/1.0'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', 'replace')


def tr_baidu(text, to, cfg):
    appid = (cfg.get('baidu_appid') or '').strip()
    key = (cfg.get('baidu_key') or '').strip()
    if not appid or not key:
        raise RuntimeError('未配置百度翻译 APP ID / 密钥')
    salt = str(random.randint(10000, 99999))
    sign = hashlib.md5((appid + text + salt + key).encode('utf-8')).hexdigest()
    params = {'q': text, 'from': 'auto', 'to': BMAP.get(to, 'zh'),
              'appid': appid, 'salt': salt, 'sign': sign}
    js = json.loads(_http('https://fanyi-api.baidu.com/api/trans/vip/translate',
                          urllib.parse.urlencode(params).encode('utf-8')))
    if 'error_code' in js:
        raise RuntimeError('百度翻译错误 %s: %s'
                           % (js['error_code'], js.get('error_msg', '')))
    return '\n'.join(x['dst'] for x in js.get('trans_result', []))


def tr_google(text, to, cfg):
    url = ('https://translate.googleapis.com/translate_a/single'
           '?client=gtx&sl=auto&tl=%s&dt=t&q=%s'
           % (GMAP.get(to, 'zh-CN'), urllib.parse.quote(text)))
    js = json.loads(_http(url))
    return ''.join(p[0] for p in js[0] if p and p[0])


def guess_source(text, tl):
    """MyMemory 不接受 auto|xx，需要具体源语言"""
    src = 'zh-CN'
    if not any('\u4e00' <= ch <= '\u9fff' for ch in text):
        src = 'en'
    if src == tl:
        src = 'en' if tl != 'en' else 'zh-CN'
    return src


def tr_mymemory(text, to, cfg):
    tl = GMAP.get(to, 'zh-CN')
    src = guess_source(text, tl)
    url = ('https://api.mymemory.translated.net/get?q=%s&langpair=%s|%s'
           % (urllib.parse.quote(text), src, tl))
    js = json.loads(_http(url))
    out = js.get('responseData', {}).get('translatedText')
    if not out:
        raise RuntimeError('MyMemory 返回为空')
    return out


def translate(text, to, cfg):
    backend = cfg.get('backend', 'baidu')
    order = {'baidu': [tr_baidu, tr_google, tr_mymemory],
             'google': [tr_google, tr_mymemory, tr_baidu],
             'mymemory': [tr_mymemory, tr_google, tr_baidu]}[backend]
    last = None
    for fn in order:
        try:
            return fn(text, to, cfg)
        except Exception as e:
            last = e
    raise RuntimeError('翻译失败：%s' % last)


def looks_like_url(text):
    t = (text or '').strip()
    if re.match(r'^(https?|ftp)://\S+$', t):
        return t
    if re.match(r'^www\.\S+\.\w{2,}(/\S*)?$', t):
        return 'https://' + t
    return None


# ─────────────────── 鼠标监听 ───────────────────

WIDGET_HINTS = ('wallet', 'rss', 'notes', 'calendar_widget', 'widget.py',
                'frame', 'music', 'radio', 'desktop-movie', 'desktop-shell',
                'timer_alarm', 'monitor.py', 'taskbar-info', 'main.py')


def window_class_at_pointer():
    """取鼠标下窗口的 WM_CLASS(用来识别是不是在拖动桌面挂件)"""
    try:
        out = subprocess.run(['xdotool', 'getmouselocation', '--shell'],
                             capture_output=True, text=True, timeout=2).stdout
        wid = ''
        for line in out.splitlines():
            if line.startswith('WINDOW='):
                wid = line.split('=', 1)[1].strip()
        if not wid:
            return ''
        pr = subprocess.run(['xprop', '-id', wid, 'WM_CLASS'],
                            capture_output=True, text=True, timeout=2).stdout
        return pr.lower()
    except Exception:
        return ''


def is_widget_window(cls):
    return any(h in cls for h in WIDGET_HINTS)


class MouseWatcher:
    """监听左键按下/松开，识别"按住划过"动作"""

    def __init__(self, cfg, on_drag_select, on_escape=None):
        self.cfg = cfg
        self.on_drag_select = on_drag_select
        self.on_escape = on_escape
        self.fds = []
        self.press_pos = None
        self.press_cls = ''
        self.press_t = 0.0
        self._last_action = 0.0
        self._last_rescan = time.time()
        self._rescan()
        GLib.timeout_add(100, self._poll)

    def _devices(self):
        """只挑选指针类（鼠标）设备。

        evdev 的事件流是排他消费的：某个设备一旦被一个进程读走，
        其它进程就读不到了。本工具只需要 BTN_LEFT / KEY_ESC，
        如果把全部 event* 都打开，就会把键盘事件也吃掉，
        导致 shot-ocr 等同样用 evdev 监听快捷键的程序完全失效。
        这里按 sysfs 的 capabilities 过滤，只开指针设备。
        """
        out = []
        for path in sorted(glob.glob('/dev/input/event*')):
            name = os.path.basename(path)
            base = '/sys/class/input/%s/device' % name
            try:
                ev = _parse_cap(os.path.join(base, 'capabilities/ev'))
                rel = _parse_cap(os.path.join(base, 'capabilities/rel'))
            except Exception:
                # 读不到能力信息时保守跳过，避免抢占键盘
                continue
            # EV_REL(0x02) 表示该设备能上报相对位移，即指针类
            if ev & 0x02 and (rel & 0x01 or rel & 0x02 or rel & 0x04):
                out.append(path)
        return out

    def _rescan(self):
        have = {p for _, p in self.fds}
        for path in self._devices():
            if path in have:
                continue
            try:
                fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
                self.fds.append((fd, path))
            except Exception:
                pass

    def _poll(self):
        now = time.time()
        if now - self._last_rescan > 5:
            self._last_rescan = now
            self._rescan()
        for fd, path in list(self.fds):
            try:
                while True:
                    data = os.read(fd, 4096)
                    if not data:
                        break
                    buf = data
                    while len(buf) >= 24:
                        _s, _u, etype, code, value = struct.unpack(
                            'llHHi', buf[:24])
                        buf = buf[24:]
                        if etype == EV_KEY and code == BTN_LEFT:
                            self._on_button(value)
                        elif etype == EV_KEY and code == KEY_ESC and value == 1:
                            if self.on_escape:
                                GLib.idle_add(self.on_escape)
            except BlockingIOError:
                continue
            except OSError:
                try:
                    os.close(fd)
                except Exception:
                    pass
                self.fds = [(f, p) for f, p in self.fds if f != fd]
            except Exception:
                pass
        return True

    def _on_button(self, value):
        if not self.cfg.get('enabled', True):
            return
        now = time.time()
        if now - self._last_action < 0.05:
            return
        if value == 1:
            x, y = pointer_xy()
            self.press_pos = (x, y)
            self.press_t = now
            self.press_cls = window_class_at_pointer()
        elif value == 0 and self.press_pos:
            x, y = pointer_xy()
            x0, y0 = self.press_pos
            self.press_pos = None
            if None in (x, y, x0, y0):
                return
            dist = ((x - x0) ** 2 + (y - y0) ** 2) ** 0.5
            if (dist >= float(self.cfg.get('min_distance', 14))
                    and now - self.press_t >= float(self.cfg.get('min_interval', 0.12))):
                # 拖动桌面挂件/工具条窗口时不要弹(那不是划词)
                if is_widget_window(self.press_cls or ''):
                    self._last_action = now
                    return
                self._last_action = now
                GLib.idle_add(self.on_drag_select, x, y)


# ─────────────────── 工具条窗口 ───────────────────

CSS = b'''
window { background: transparent; }
#cbar { background: transparent; padding: 5px 6px; }
#cbar button { padding: 4px 10px; margin: 1px; border-radius: 6px;
               background: rgba(0,0,0,0.06); color: #1a1a1a;
               border: none; }
#cbar button:hover { background: rgba(64,140,255,0.30); color: #000000; }
#cbar label { color: #1a1a1a; }
#ctrans { color: #1a1a1a; }
'''


class ToolbarWindow(Gtk.Window):
    def __init__(self, app):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.app = app
        self.text = ''
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_accept_focus(False)
        self.set_can_focus(False)
        try:
            self.set_type_hint(Gdk.WindowTypeHint.POPUP_MENU)
        except Exception:
            pass
        # 关键: 窗口自己画白色圆角底(不再由主题画方角高亮), 圆角处才是透明的
        self.set_app_paintable(True)
        try:
            vis = self.get_screen().get_rgba_visual()
            if vis is not None:
                self.set_visual(vis)
        except Exception:
            pass
        self.connect('draw', self._on_draw)
        prov = Gtk.CssProvider()
        try:
            prov.load_from_data(CSS)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(), prov,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        except Exception:
            pass

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        outer.set_name('cbar')
        self.add(outer)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        outer.pack_start(row, False, False, 0)

        for name in self.app.cfg.get('buttons', DEFAULTS['buttons']):
            b = Gtk.Button(label=name)
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.connect('clicked', self.on_click, name)
            row.pack_start(b, False, False, 0)
        close = Gtk.Button(label='✕')
        close.set_relief(Gtk.ReliefStyle.NONE)
        close.connect('clicked', lambda w: self.hide_bar())
        row.pack_start(close, False, False, 0)

        self.info = Gtk.Label(label='')
        self.info.set_name('ctrans')
        self.info.set_line_wrap(True)
        self.info.set_max_width_chars(60)
        self.info.set_xalign(0)
        outer.pack_start(self.info, False, False, 4)
        self.info.hide()

        self.connect('enter-notify-event', self.on_enter)
        self.connect('leave-notify-event', self.on_leave)
        self._hide_id = None
        self.inside = False

    def _on_draw(self, w, cr):
        """自绘白色圆角底: 圆角外保持透明, 不会出现黑色方角"""
        try:
            cr.set_operator(cairo.OPERATOR_CLEAR)
            cr.paint()
            cr.set_operator(cairo.OPERATOR_OVER)
            ww = w.get_allocated_width()
            hh = w.get_allocated_height()
            r = 10.0
            cr.new_path()
            cr.arc(r + 0.5, r + 0.5, r, 3.1416, 1.5 * 3.1416)
            cr.arc(ww - r - 0.5, r + 0.5, r, 1.5 * 3.1416, 2 * 3.1416)
            cr.arc(ww - r - 0.5, hh - r - 0.5, r, 0, 0.5 * 3.1416)
            cr.arc(r + 0.5, hh - r - 0.5, r, 0.5 * 3.1416, 3.1416)
            cr.close_path()
            cr.set_source_rgba(1.0, 1.0, 1.0, 0.97)
            cr.fill_preserve()
            cr.set_source_rgba(0.0, 0.0, 0.0, 0.14)
            cr.set_line_width(1)
            cr.stroke()
        except Exception:
            pass
        return False

    def on_enter(self, w, e):
        self.inside = True
        return False

    def on_leave(self, w, e):
        self.inside = False
        # 默认不自动隐藏（hide_delay=0）；只有配置了时长才会自动收起
        self.schedule_hide()
        return False

    def flash(self, text):
        self.info.set_text(text)
        self.info.show()
        self.show_all()
        self.schedule_hide(1600)

    def show_for(self, text, x, y):
        self.text = text
        self.show_all()
        self.info.set_text('')
        self.info.hide()
        self._place(x, y)
        self.schedule_hide()          # 默认不自动隐藏；点 ✕ 手动关闭

    def _place(self, x, y):
        w, h = self.get_size_request()
        aw = self.get_allocated_width() or w
        ah = self.get_allocated_height() or h
        scr = self.get_screen()
        sw, sh = scr.get_width(), scr.get_height()
        off = int(self.app.cfg.get('offset_y', 18))
        px = min(max(0, x - aw // 2), max(0, sw - aw - 4))
        py = y + off
        if py + ah > sh - 4:
            py = max(0, y - ah - off)
        self.move(px, py)

    def schedule_hide(self, ms=None):
        """ms 为空时按配置决定：0 或未设置表示不自动隐藏（需手动点 ✕）"""
        if ms is None:
            ms = int(self.app.cfg.get('hide_delay', 0) or 0)
        if ms <= 0:
            if self._hide_id:
                GLib.source_remove(self._hide_id)
                self._hide_id = None
            return
        if self._hide_id:
            GLib.source_remove(self._hide_id)
        self._hide_id = GLib.timeout_add(ms, self._auto_hide)

    def _auto_hide(self):
        self._hide_id = None
        if not self.inside:
            self.hide_bar()
        else:
            self.schedule_hide(1500)
        return False

    def hide_bar(self):
        if self._hide_id:
            GLib.source_remove(self._hide_id)
            self._hide_id = None
        self.hide()

    # ---------- 按钮动作 ----------
    def on_click(self, w, name):
        try:
            self.do_action(name)
        except Exception as e:
            self.flash('出错了：%s' % e)
        return True

    def send_key(self, key):
        cmd = ['xdotool']
        if self.app.target_win:
            cmd += ['windowactivate', '--sync', str(self.app.target_win)]
        cmd += ['key', '--clearmodifiers', key]
        try:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        except Exception:
            pass

    def do_action(self, name):
        text = self.text or ''
        if name == '复制':
            cb = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
            cb.set_text(text, -1)
            cb.store()
            self.flash('已复制 %d 字' % len(text))
        elif name == '粘贴':
            self.send_key('ctrl+v')
            self.schedule_hide(500)
        elif name == '剪切':
            self.send_key('ctrl+x')
            self.schedule_hide(500)
        elif name == '全选':
            self.send_key('ctrl+a')
            self.schedule_hide(500)
        elif name == '打开链接':
            url = looks_like_url(text)
            if url:
                subprocess.Popen(['xdg-open', url])
                self.hide_bar()
            else:
                self.flash('选中的内容不是网址')
        elif name == '搜索':
            q = urllib.parse.quote(text.strip()[:200])
            subprocess.Popen(['xdg-open', 'https://www.bing.com/search?q=' + q])
            self.hide_bar()
        elif name == '翻译':
            self.do_translate()
        else:
            self.flash('未知操作：%s' % name)

    def do_translate(self):
        text = (self.text or '').strip()
        if not text:
            self.flash('没有可翻译的文字')
            return
        to = self.app.cfg.get('to_lang', 'zh')
        self.flash('正在翻译…')

        def work():
            try:
                out = translate(text[:1500], to, self.app.cfg)
            except Exception as e:
                GLib.idle_add(self.flash, '翻译失败：%s' % e)
                return
            GLib.idle_add(self.flash, out)

        threading.Thread(target=work, daemon=True).start()


# ─────────────────── 设置 ───────────────────

class SettingsDialog(Gtk.Dialog):
    def __init__(self, parent, cfg):
        super().__init__(title='划选复制工具条 · 设置', transient_for=parent, modal=True)
        self.cfg = cfg
        self.set_default_size(520, 340)
        self.add_button('取消', Gtk.ResponseType.CANCEL)
        self.add_button('保存', Gtk.ResponseType.OK)
        box = self.get_content_area()
        box.set_border_width(12)
        box.set_spacing(8)
        grid = Gtk.Grid(column_spacing=10, row_spacing=8)
        box.pack_start(grid, False, False, 0)
        r = 0

        def row(label, w):
            nonlocal r
            lab = Gtk.Label(label=label)
            lab.set_xalign(0)
            grid.attach(lab, 0, r, 1, 1)
            grid.attach(w, 1, r, 1, 1)
            r += 1

        self.backend = Gtk.ComboBoxText()
        for k, n in (('baidu', '百度翻译'), ('google', 'Google 免费接口'),
                     ('mymemory', 'MyMemory 免费接口')):
            self.backend.append(k, n)
        self.backend.set_active_id(cfg.get('backend', 'baidu'))
        row('翻译引擎', self.backend)

        self.to_lang = Gtk.ComboBoxText()
        for k, n in LANG_NAME.items():
            self.to_lang.append(k, n)
        self.to_lang.set_active_id(cfg.get('to_lang', 'zh'))
        row('翻译目标语言', self.to_lang)

        self.appid = Gtk.Entry()
        self.appid.set_text(cfg.get('baidu_appid', ''))
        row('百度 APP ID', self.appid)
        self.key = Gtk.Entry()
        self.key.set_text(cfg.get('baidu_key', ''))
        row('百度密钥', self.key)

        self.dist = Gtk.SpinButton.new_with_range(4, 80, 1)
        self.dist.set_value(float(cfg.get('min_distance', 14)))
        row('划过多少像素后弹出', self.dist)

        self.delay = Gtk.SpinButton.new_with_range(800, 10000, 200)
        self.delay.set_value(float(cfg.get('hide_delay', 2600)))
        row('自动隐藏（毫秒）', self.delay)

        tip = Gtk.Label(label='按钮可在配置文件 ~/.config/copy-toolbar/config.json 的 '
                              'buttons 里增删。')
        tip.set_xalign(0)
        tip.set_line_wrap(True)
        box.pack_start(tip, False, False, 4)
        self.show_all()

    def apply(self):
        c = self.cfg
        c['backend'] = self.backend.get_active_id() or 'baidu'
        c['to_lang'] = self.to_lang.get_active_id() or 'zh'
        c['baidu_appid'] = self.appid.get_text().strip()
        c['baidu_key'] = self.key.get_text().strip()
        c['min_distance'] = int(self.dist.get_value())
        c['hide_delay'] = int(self.delay.get_value())
        save_cfg(c)


# ─────────────────── 主程序 ───────────────────

import fcntl

LOCK_PATH = os.path.join(HOME, '.cache', '%s.lock' % APP)
ICON_PATH = '/usr/share/icons/hicolor/scalable/apps/copy-toolbar.svg'


class CopyToolbarApp:
    def __init__(self, cfg):
        self.cfg = cfg
        self.target_win = None
        self.bar = ToolbarWindow(self)
        self._last_text = ''
        self.watcher = MouseWatcher(cfg, self.on_drag_select, self.on_escape)
        self.tray = None
        self._make_indicator()

    # ---------- 划选处理 ----------
    def on_drag_select(self, x, y):
        if not self.cfg.get('enabled', True):
            return False
        # 截图工具正在框选时不弹工具条（避免两个东西同时出现）
        if os.path.exists(SHOT_FLAG):
            return False
        # 取前台窗口、读选区都可能阻塞，一律放到线程里做，绝不卡住主循环
        threading.Thread(target=self._capture, args=(x, y), daemon=True).start()
        return False

    def _capture(self, x, y):
        self.target_win = self.get_active_window()
        time.sleep(0.06)          # 等应用把选区内容写好
        GLib.idle_add(self._read_primary, x, y)

    def _read_primary(self, x, y):
        """用异步接口读主选区，避免 wait_for_text 阻塞主循环
        （一旦卡住，之后工具条就再也不会弹出了）"""
        try:
            cb = Gtk.Clipboard.get(Gdk.SELECTION_PRIMARY)
            cb.request_text(self._on_primary_text, (x, y))
        except Exception:
            pass
        return False

    def _on_primary_text(self, clipboard, text, data):
        x, y = data
        if not text or not text.strip():
            return
        t = text.strip()
        # 同一段文字只弹一次(拖动窗口时选区没变, 不该再弹)
        if t == self._last_text:
            return
        self._last_text = t
        self.bar.show_for(t, x, y)

    def on_escape(self):
        """按 Esc 隐藏工具条"""
        try:
            if self.bar.get_visible():
                self.bar.hide_bar()
        except Exception:
            pass
        return False

    def get_active_window(self):
        try:
            out = subprocess.run(['xdotool', 'getactivewindow'],
                                 capture_output=True, text=True, timeout=3).stdout
            out = out.strip()
            return int(out) if out.isdigit() else None
        except Exception:
            return None

    # ---------- 托盘 ----------
    def _make_indicator(self):
        """用 Gtk.StatusIcon（和鼠标炫彩拖尾一致）：
        菜单由本进程渲染 → 字号正常、白底黑字，跟随系统主题"""
        self.tray = None
        self.menu = Gtk.Menu()
        head = Gtk.MenuItem(label='划选复制工具条')
        head.set_sensitive(False)
        self.menu.append(head)
        self.menu.append(Gtk.SeparatorMenuItem())
        self.enable_item = Gtk.CheckMenuItem(label='启用（划选后弹出工具条）')
        self.enable_item.set_active(bool(self.cfg.get('enabled', True)))
        self.enable_item.connect('toggled', self.on_toggle_enable)
        self.menu.append(self.enable_item)
        self.menu.append(Gtk.SeparatorMenuItem())

        def add(label, cb):
            it = Gtk.MenuItem(label=label)
            it.connect('activate', cb)
            self.menu.append(it)

        add('显示上次划选内容', lambda w: self.show_last())
        add('隐藏工具条', lambda w: self.bar.hide_bar())
        add('翻译目标语言：%s' % LANG_NAME.get(self.cfg.get('to_lang', 'zh'), ''), self.pick_lang)
        add('⚙ 设置', lambda w: self.settings())
        add('ℹ 关于', lambda w: self.about())
        self.menu.append(Gtk.SeparatorMenuItem())
        add('🚪 退出', lambda w: self.quit())
        self.menu.show_all()
        try:
            icon = Gtk.StatusIcon()
            icon.set_from_icon_name(APP)
            if not icon.get_icon_name():
                icon.set_from_file(ICON_PATH)
            icon.set_tooltip_text('划选复制工具条 — 右键打开菜单')
            icon.connect('popup-menu', self._on_tray_popup)
            icon.connect('activate', lambda i: self.show_last())
            icon.set_visible(True)
            self.tray = icon
        except Exception:
            self.tray = None

    def _on_tray_popup(self, icon, button, activate_time):
        self.menu.popup(None, None, Gtk.StatusIcon.position_menu, icon,
                        button, activate_time)

    def on_toggle_enable(self, item):
        self.cfg['enabled'] = item.get_active()
        save_cfg(self.cfg)
        if not item.get_active():
            self.bar.hide_bar()

    def pick_lang(self, w):
        langs = list(LANG_NAME.items())
        cur = self.cfg.get('to_lang', 'zh')
        idx = [k for k, _ in langs].index(cur) if cur in dict(langs) else 0
        nxt = langs[(idx + 1) % len(langs)]
        self.cfg['to_lang'] = nxt[0]
        save_cfg(self.cfg)
        for it in self.menu.get_children():
            if isinstance(it, Gtk.MenuItem) and it.get_label().startswith('翻译目标语言'):
                it.set_label('翻译目标语言：%s' % nxt[1])

    def show_last(self):
        if self.bar.text:
            x, y = pointer_xy()
            self.bar.show_for(self.bar.text, x or 200, y or 200)
        else:
            pass

    def settings(self):
        d = SettingsDialog(None, self.cfg)
        if d.run() == Gtk.ResponseType.OK:
            d.apply()
        d.destroy()

    def about(self):
        d = Gtk.MessageDialog(modal=True, message_type=Gtk.MessageType.INFO,
                              buttons=Gtk.ButtonsType.OK,
                              text='划选复制工具条 1.0.0')
        d.format_secondary_text(
            '按住左键划过文字 → 松开后在下方弹出工具条：\n'
            '复制 / 粘贴 / 剪切 / 全选 / 打开链接 / 搜索 / 翻译 / 关闭\n'
            '托盘图标可随时暂停或恢复；翻译引擎与语言在设置里切换。')
        d.run()
        d.destroy()

    def quit(self):
        save_cfg(self.cfg)
        try:
            if os.path.exists(LOCK_PATH):
                os.unlink(LOCK_PATH)
        except Exception:
            pass
        Gtk.main_quit()


def main():
    os.makedirs(os.path.dirname(LOCK_PATH), exist_ok=True)
    lock = open(LOCK_PATH, 'w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except Exception:
        print('已在运行')
        return
    cfg = load_cfg()
    app = CopyToolbarApp(cfg)
    Gtk.main()


if __name__ == '__main__':
    main()
