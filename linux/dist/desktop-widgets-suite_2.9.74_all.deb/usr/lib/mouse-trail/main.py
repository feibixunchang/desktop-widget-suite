#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""鼠标炫彩拖尾特效 mouse-trail 2.0.0

* 鼠标移动时产生绚丽粒子拖尾：烟雾/闪钻/星星/泡泡/丝带/彩虹/火焰/雪花/爱心/花瓣/星云/礼花/智能混合
* 覆盖全屏的点击穿透窗口，不影响任何操作与点击
* 托盘图标 + 右键菜单：切换特效、大小、密度、帧率、开关、开机自启、关于、退出
* 低占用设计：
    - 只在有粒子或鼠标移动时才绘制，静止时定时器降到最低频率
    - 只重绘脏区（局部重绘），不做整屏刷新
    - 粒子对象池复用；粒子上限可调
    - 用同心圆代替昂贵的径向渐变
"""
import json
import math
import os
import random
import signal
import sys
import time

import gi

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gtk, Gdk, GLib
import cairo

APP = 'mouse-trail'
TITLE = '鼠标炫彩拖尾'
CONFIG_DIR = os.path.expanduser('~/.config/%s' % APP)
CONFIG_PATH = os.path.join(CONFIG_DIR, 'config.json')
LOCK_PATH = os.path.expanduser('~/.cache/%s.lock' % APP)
AUTOSTART_PATH = os.path.expanduser('~/.config/autostart/%s.desktop' % APP)

EFFECTS = [
    ('auto', '智能混合'),
    ('smoke', '烟雾'),
    ('sparkle', '闪钻'),
    ('star', '星星'),
    ('bubble', '泡泡'),
    ('ribbon', '丝带'),
    ('rainbow', '彩虹'),
    ('fire', '火焰'),
    ('snow', '雪花'),
    ('heart', '爱心'),
    ('petal', '花瓣'),
    ('galaxy', '星云'),
    ('confetti', '礼花'),
    ('off', '关闭特效'),
]
EFFECT_KEYS = [e[0] for e in EFFECTS]
AUTO_POOL = ['smoke', 'sparkle', 'star', 'bubble', 'ribbon', 'rainbow',
             'fire', 'snow', 'heart', 'petal', 'galaxy', 'confetti']

DEFAULT_CFG = {
    'effect': 'auto',
    'size': 1.0,
    'density': 1.0,
    'max_particles': 150,
    'eco': True,          # 省电模式: 移动时进一步降帧/限粒子
    'fps': 30,
    'enabled': True,
}


def load_config():
    cfg = dict(DEFAULT_CFG)
    try:
        with open(CONFIG_PATH) as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    if cfg.get('effect') not in EFFECT_KEYS:
        cfg['effect'] = 'auto'
    return cfg


def save_config(cfg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_PATH, 'w') as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def single_instance():
    """同一用户只保留一个实例，新实例会接管旧实例"""
    try:
        import fcntl
        os.makedirs(os.path.dirname(LOCK_PATH), exist_ok=True)
        f = open(LOCK_PATH, 'a+')
    except Exception:
        return None
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except Exception:
        try:
            f.seek(0)
            old = f.read().strip()
            if old.isdigit() and int(old) != os.getpid():
                try:
                    with open('/proc/%d/cmdline' % int(old), 'rb') as cf:
                        if b'mouse-trail' in cf.read():
                            os.kill(int(old), signal.SIGTERM)
                            time.sleep(0.4)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except Exception:
            return None
    try:
        f.seek(0)
        f.truncate()
        f.write(str(os.getpid()))
        f.flush()
    except Exception:
        pass
    return f


def autostart_enabled():
    return os.path.exists(AUTOSTART_PATH)


def set_autostart(enable):
    try:
        if enable:
            os.makedirs(os.path.dirname(AUTOSTART_PATH), exist_ok=True)
            with open(AUTOSTART_PATH, 'w') as f:
                f.write('[Desktop Entry]\n'
                        'Type=Application\n'
                        'Name=%s\n'
                        'Exec=/usr/bin/%s\n'
                        'X-GNOME-Autostart-enabled=true\n'
                        'X-GNOME-Autostart-Delay=1\n'
                        'NoDisplay=true\n' % (TITLE, APP))
        else:
            if os.path.exists(AUTOSTART_PATH):
                os.remove(AUTOSTART_PATH)
    except Exception:
        pass
    return autostart_enabled()


def hsv(h, s, v):
    """(h in 0..1) -> (r,g,b) 0..1，比 colorsys 更快且不占额外导入"""
    h = h % 1.0
    i = int(h * 6.0)
    f = h * 6.0 - i
    p = v * (1.0 - s)
    q = v * (1.0 - s * f)
    t = v * (1.0 - s * (1.0 - f))
    i = i % 6
    if i == 0:
        return v, t, p
    if i == 1:
        return q, v, p
    if i == 2:
        return p, v, t
    if i == 3:
        return p, q, v
    if i == 4:
        return t, p, v
    return v, p, q

class P(object):
    """粒子（用 __slots__ 减少内存与属性访问开销）"""
    __slots__ = ('kind', 'x', 'y', 'vx', 'vy', 'grav', 'life', 'maxlife',
                 'size', 'grow', 'rot', 'vrot', 'r', 'g', 'b', 'a',
                 'sway', 'phase', 'w', 'h')


class Particles(object):
    def __init__(self, cap):
        self.cap = cap
        self.items = []
        self.free = []
        self.dirty = None      # 本帧需要重绘的区域 (x0,y0,x1,y1)

    def set_cap(self, cap):
        self.cap = max(40, int(cap))

    def take(self):
        if self.free:
            p = self.free.pop()
        else:
            if len(self.items) >= self.cap:
                return None
            p = P()
        self.items.append(p)
        return p

    def trim(self, cap):
        """粒子上限收紧时, 丢弃最老的几个(并标记重绘区域)"""
        cap = max(20, int(cap))
        items = self.items
        while len(items) > cap:
            p = items.pop(0)
            self.touch(p.x, p.y, p.size * 2 + 6)
            self.free.append(p)

    def kill(self, i):
        p = self.items[i]
        self.items[i] = self.items[-1]
        self.items.pop()
        self.free.append(p)

    def touch(self, x, y, r):
        d = self.dirty
        x0, y0, x1, y1 = x - r, y - r, x + r, y + r
        if d is None:
            self.dirty = [x0, y0, x1, y1]
        else:
            if x0 < d[0]:
                d[0] = x0
            if y0 < d[1]:
                d[1] = y0
            if x1 > d[2]:
                d[2] = x1
            if y1 > d[3]:
                d[3] = y1

    # ---------- 生成 ----------
    def emit(self, kind, x, y, dx, dy, speed, sz, dens):
        n = 1
        if kind in ('sparkle', 'confetti'):
            n = 2
        elif kind == 'smoke':
            n = 1
        n = max(1, int(round(n * dens)))
        for _ in range(n):
            if kind == 'sparkle':
                self._sparkle(x, y, dx, dy, speed, sz)
            elif kind == 'star':
                self._star(x, y, dx, dy, speed, sz)
            elif kind == 'smoke':
                self._smoke(x, y, sz)
            elif kind == 'bubble':
                self._bubble(x, y, sz)
            elif kind == 'fire':
                self._fire(x, y, sz)
            elif kind == 'snow':
                self._snow(x, y, sz)
            elif kind == 'heart':
                self._heart(x, y, sz)
            elif kind == 'petal':
                self._petal(x, y, sz)
            elif kind == 'galaxy':
                self._galaxy(x, y, sz)
            elif kind == 'confetti':
                self._confetti(x, y, dx, dy, speed, sz)

    def _new(self, kind, x, y, life, size):
        p = self.take()
        if p is None:
            return None
        p.kind = kind
        p.x = x
        p.y = y
        p.vx = p.vy = 0.0
        p.grav = 0.0
        p.life = p.maxlife = life
        p.size = size
        p.grow = 0.0
        p.rot = random.uniform(0, 6.2832)
        p.vrot = 0.0
        p.r = p.g = p.b = 1.0
        p.a = 1.0
        p.sway = 0.0
        p.phase = random.uniform(0, 6.2832)
        p.w = p.h = 0.0
        return p

    def _sparkle(self, x, y, dx, dy, speed, sz):
        p = self._new('dot', x + random.uniform(-4, 4), y + random.uniform(-4, 4),
                      random.uniform(0.45, 0.9), random.uniform(1.6, 3.6) * sz)
        if p is None:
            return
        a = math.atan2(dy, dx) + random.uniform(-0.7, 0.7)
        v = speed * random.uniform(0.25, 0.6)
        p.vx = math.cos(a) * v
        p.vy = math.sin(a) * v
        p.r, p.g, p.b = hsv(random.random(), 0.75, 1.0)

    def _star(self, x, y, dx, dy, speed, sz):
        p = self._new('star', x, y, random.uniform(0.6, 1.15), random.uniform(4.0, 8.0) * sz)
        if p is None:
            return
        p.vx = random.uniform(-25, 25)
        p.vy = random.uniform(-40, -6)
        p.vrot = random.uniform(-3, 3)
        if random.random() < 0.45:
            p.r = p.g = p.b = 1.0
        else:
            p.r, p.g, p.b = hsv(random.uniform(0.08, 0.16), 1.0, 1.0)

    def _smoke(self, x, y, sz):
        p = self._new('smoke', x + random.uniform(-5, 5), y + random.uniform(-5, 5),
                      random.uniform(0.9, 1.7), random.uniform(7.0, 13.0) * sz)
        if p is None:
            return
        p.vx = random.uniform(-12, 12)
        p.vy = random.uniform(-26, -6)
        p.grow = 16.0 * sz
        p.sway = 9.0
        t = random.uniform(0.45, 0.95)
        p.r = t
        p.g = t
        p.b = min(1.0, t * 1.06)
        p.a = 0.5

    def _bubble(self, x, y, sz):
        p = self._new('bubble', x + random.uniform(-6, 6), y + random.uniform(-6, 6),
                      random.uniform(0.9, 1.6), random.uniform(4.0, 9.0) * sz)
        if p is None:
            return
        p.vy = random.uniform(-52, -18)
        p.vx = random.uniform(-16, 16)
        p.grow = 3.5 * sz
        p.sway = 14.0
        p.r, p.g, p.b = hsv(random.uniform(0.5, 0.72), 0.55, 1.0)

    def _fire(self, x, y, sz):
        p = self._new('fire', x + random.uniform(-4, 4), y + random.uniform(-4, 4),
                      random.uniform(0.35, 0.75), random.uniform(4.0, 8.5) * sz)
        if p is None:
            return
        p.vy = random.uniform(-120, -55)
        p.vx = random.uniform(-22, 22)
        p.grav = 30.0
        h = random.uniform(0.0, 0.13)
        p.r, p.g, p.b = hsv(h, 1.0, 1.0)

    def _snow(self, x, y, sz):
        p = self._new('snow', x + random.uniform(-8, 8), y + random.uniform(-8, 8),
                      random.uniform(1.0, 1.9), random.uniform(3.0, 6.0) * sz)
        if p is None:
            return
        p.vy = random.uniform(12, 34)
        p.vx = random.uniform(-10, 10)
        p.sway = 16.0
        p.vrot = random.uniform(-1.2, 1.2)
        p.r = p.g = p.b = 1.0

    def _heart(self, x, y, sz):
        p = self._new('heart', x, y, random.uniform(0.8, 1.4), random.uniform(5.0, 9.0) * sz)
        if p is None:
            return
        p.vy = random.uniform(-52, -20)
        p.sway = 13.0
        h = random.uniform(0.93, 1.02)
        p.r, p.g, p.b = hsv(h, 0.72, 1.0)

    def _petal(self, x, y, sz):
        p = self._new('petal', x, y, random.uniform(0.9, 1.6), random.uniform(4.0, 8.0) * sz)
        if p is None:
            return
        p.vy = random.uniform(-30, -4)
        p.vx = random.uniform(-24, 24)
        p.grav = 14.0
        p.vrot = random.uniform(-3.4, 3.4)
        p.sway = 18.0
        p.r, p.g, p.b = hsv(random.uniform(0.9, 1.0), 0.45, 1.0)
        p.w = 1.7

    def _galaxy(self, x, y, sz):
        p = self._new('galaxy', x, y, random.uniform(0.9, 1.5), random.uniform(9.0, 16.0) * sz)
        if p is None:
            return
        p.vx = random.uniform(-8, 8)
        p.vy = random.uniform(-10, 4)
        p.grow = 7.0 * sz
        p.r, p.g, p.b = hsv(random.uniform(0.6, 0.82), 0.85, 1.0)
        p.a = 0.42
        if random.random() < 0.5:
            sp = self._new('dot', x + random.uniform(-14, 14), y + random.uniform(-14, 14),
                           random.uniform(0.5, 1.1), random.uniform(1.2, 2.4) * sz)
            if sp is not None:
                sp.r = sp.g = sp.b = 1.0

    def _confetti(self, x, y, dx, dy, speed, sz):
        p = self._new('confetti', x, y, random.uniform(0.7, 1.3), random.uniform(3.0, 6.0) * sz)
        if p is None:
            return
        a = math.atan2(dy, dx) + random.uniform(-1.0, 1.0)
        v = speed * random.uniform(0.2, 0.55)
        p.vx = math.cos(a) * v
        p.vy = math.sin(a) * v - 20
        p.grav = 90.0
        p.vrot = random.uniform(-9, 9)
        p.r, p.g, p.b = hsv(random.random(), 0.85, 1.0)
        p.w = 0.45

    # ---------- 更新 ----------
    def update(self, dt):
        items = self.items
        i = len(items) - 1
        while i >= 0:
            p = items[i]
            p.life -= dt
            if p.life <= 0.0:
                self.touch(p.x, p.y, p.size * 2 + 6)
                self.kill(i)
                i -= 1
                continue
            if p.vx:
                p.x += p.vx * dt
            if p.vy:
                p.y += p.vy * dt
            if p.grav:
                p.vy += p.grav * dt
            if p.grow:
                p.size += p.grow * dt
            if p.vrot:
                p.rot += p.vrot * dt
            if p.sway:
                p.x += math.sin(p.phase + p.life * 4.5) * p.sway * dt
            self.touch(p.x, p.y, p.size * 2 + 6)
            i -= 1

    def take_dirty(self):
        d = self.dirty
        self.dirty = None
        return d



def _star_path(cr, x, y, r, ri, rot, points=4):
    cr.new_path()
    step = math.pi / points
    a = rot
    for i in range(points * 2):
        rad = r if i % 2 == 0 else ri
        cr.line_to(x + math.cos(a) * rad, y + math.sin(a) * rad)
        a += step
    cr.close_path()


def _heart_path(cr, x, y, r):
    cr.new_path()
    cr.move_to(x, y + r * 0.85)
    cr.curve_to(x - r * 1.5, y - r * 0.45, x - r * 0.45, y - r * 1.25, x, y - r * 0.35)
    cr.curve_to(x + r * 0.45, y - r * 1.25, x + r * 1.5, y - r * 0.45, x, y + r * 0.85)
    cr.close_path()


def _circle(cr, x, y, r):
    cr.new_path()
    cr.arc(x, y, r, 0, 6.2832)


def draw_particle(cr, p):
    t = p.life / p.maxlife
    if t > 1.0:
        t = 1.0
    a = p.a * t
    if a <= 0.02:
        return
    k = p.kind
    s = p.size
    r, g, b = p.r, p.g, p.b
    if k == 'dot':
        _circle(cr, p.x, p.y, s)
        cr.set_source_rgba(r, g, b, a)
        cr.fill()
    elif k == 'star':
        _star_path(cr, p.x, p.y, s, s * 0.3, p.rot)
        cr.set_source_rgba(r, g, b, a)
        cr.fill()
        _circle(cr, p.x, p.y, s * 0.17)
        cr.set_source_rgba(1, 1, 1, a * 0.9)
        cr.fill()
    elif k == 'smoke':
        _circle(cr, p.x, p.y, s)
        cr.set_source_rgba(r, g, b, a * 0.22)
        cr.fill()
        _circle(cr, p.x, p.y, s * 0.46)
        cr.set_source_rgba(1, 1, 1, a * 0.26)
        cr.fill()
    elif k == 'bubble':
        _circle(cr, p.x, p.y, s)
        cr.set_line_width(max(1.1, s * 0.22))
        cr.set_source_rgba(r, g, b, a * 0.95)
        cr.stroke()
        _circle(cr, p.x - s * 0.34, p.y - s * 0.34, max(0.8, s * 0.20))
        cr.set_source_rgba(1, 1, 1, a * 0.85)
        cr.fill()
    elif k == 'fire':
        _circle(cr, p.x, p.y, s)
        cr.set_source_rgba(r, g, b, a * 0.72)
        cr.fill()
        _circle(cr, p.x, p.y, s * 0.45)
        cr.set_source_rgba(1.0, 0.95, 0.55, a * 0.8)
        cr.fill()
    elif k == 'snow':
        cr.new_path()
        for i in range(3):
            ang = p.rot + i * 1.0472
            dx, dy = math.cos(ang) * s, math.sin(ang) * s
            cr.move_to(p.x - dx, p.y - dy)
            cr.line_to(p.x + dx, p.y + dy)
        cr.set_line_width(max(1.0, s * 0.20))
        cr.set_source_rgba(r, g, b, a * 0.95)
        cr.stroke()
        _circle(cr, p.x, p.y, max(0.7, s * 0.18))
        cr.set_source_rgba(1, 1, 1, a)
        cr.fill()
    elif k == 'heart':
        _heart_path(cr, p.x, p.y, s)
        cr.set_source_rgba(r, g, b, a * 0.95)
        cr.fill()
    elif k == 'petal':
        cr.save()
        cr.translate(p.x, p.y)
        cr.rotate(p.rot)
        cr.scale(1.0, p.w or 1.7)
        _circle(cr, 0, 0, s)
        cr.set_source_rgba(r, g, b, a * 0.85)
        cr.fill()
        cr.restore()
    elif k == 'galaxy':
        _circle(cr, p.x, p.y, s)
        cr.set_source_rgba(r, g, b, a * 0.26)
        cr.fill()
        _circle(cr, p.x, p.y, s * 0.5)
        cr.set_source_rgba(min(1.0, r * 0.5 + 0.5), min(1.0, g * 0.5 + 0.5), b, a * 0.38)
        cr.fill()
    elif k == 'confetti':
        cr.save()
        cr.translate(p.x, p.y)
        cr.rotate(p.rot)
        cr.new_path()
        w, h = s * 2.2, s * (p.w or 0.45) * 2.6
        cr.rectangle(-w / 2, -h / 2, w, h)
        cr.set_source_rgba(r, g, b, a)
        cr.fill()
        cr.restore()


def draw_trail(cr, pts, sz, kind, hue_base):
    """画丝带/彩虹：pts 由旧到新 [(x,y), ...]"""
    n = len(pts)
    if n < 2:
        return
    if kind == 'ribbon':
        maxw, hstep, a0 = 10.0 * sz, 0.014, 0.92
    else:
        maxw, hstep, a0 = 5.5 * sz, 0.030, 1.0
    for i in range(n - 1):
        x0, y0 = pts[i]
        x1, y1 = pts[i + 1]
        frac = (i + 1) / float(n)
        w = maxw * (0.22 + 0.78 * frac)
        a = a0 * (0.18 + 0.82 * frac)
        dx, dy = x1 - x0, y1 - y0
        d = math.hypot(dx, dy)
        if d < 0.01:
            continue
        px, py = -dy / d, dx / d
        cr.new_path()
        cr.move_to(x0 + px * w, y0 + py * w)
        cr.line_to(x1 + px * w, y1 + py * w)
        cr.line_to(x1 - px * w, y1 - py * w)
        cr.line_to(x0 - px * w, y0 - py * w)
        cr.close_path()
        r, g, b = hsv(hue_base + i * hstep, 0.85, 1.0)
        cr.set_source_rgba(r, g, b, a)
        cr.fill()


class Overlay(Gtk.Window):
    """全屏点击穿透覆盖层（override-redirect，WM 不管理、不影响点击）"""

    def __init__(self, app):
        Gtk.Window.__init__(self, type=Gtk.WindowType.POPUP)
        self.app = app
        self.set_decorated(False)
        self.set_app_paintable(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        self.set_can_focus(False)
        scr = Gdk.Screen.get_default()
        self.sw, self.sh = scr.get_width(), scr.get_height()
        vis = self.get_screen().get_rgba_visual()
        if vis:
            self.set_visual(vis)
        self.da = Gtk.DrawingArea()
        self.da.set_size_request(self.sw, self.sh)
        self.da.set_events(0)
        self.da.connect('draw', self.on_draw)
        self.add(self.da)
        self.set_size_request(self.sw, self.sh)
        self.move(0, 0)
        self.show_all()
        self.make_click_through()

    def make_click_through(self):
        """把输入区域清空 → 鼠标事件直接穿透到下层窗口"""
        try:
            win = self.get_window()
            if win is not None:
                win.input_shape_combine_region(cairo.Region(), 0, 0)
        except Exception:
            pass

    def on_draw(self, wd, cr):
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()                 # 只清掉 GTK 裁给我们的脏区
        cr.set_operator(cairo.OPERATOR_OVER)
        app = self.app
        for p in app.ps.items:
            draw_particle(cr, p)
        if app.trail_pts and app.cur_kind in ('ribbon', 'rainbow'):
            draw_trail(cr, app.trail_pts, float(app.cfg.get('size', 1.0)),
                       app.cur_kind, app.hue_base)
        return False

    def invalidate(self, x0, y0, x1, y1):
        x0 = max(0, int(x0))
        y0 = max(0, int(y0))
        x1 = min(self.sw, int(x1) + 1)
        y1 = min(self.sh, int(y1) + 1)
        if x1 - x0 < 1 or y1 - y0 < 1:
            return
        self.da.queue_draw_area(x0, y0, x1 - x0, y1 - y0)


class App(object):
    def __init__(self, cfg):
        self.cfg = cfg
        self.ps = Particles(int(cfg.get('max_particles', 320)))
        self.eff = cfg.get('effect', 'auto')
        self.cur_kind = 'sparkle'
        self.auto_kind = random.choice(AUTO_POOL)
        self.auto_until = 0.0
        self.hue_base = 0.0
        self.trail = []          # [(x, y, t)]
        self.trail_pts = []      # [(x, y)]
        self.px = self.py = None
        self.pt = 0.0
        self.prev_rect = None
        self.idle = 0
        self.interval = 25
        self.speed = 0.0          # 当前指针速度(px/s), 用于动态降载
        self.overlay = Overlay(self)
        self.tray = None
        self.tray_menu = None
        self.build_tray()
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            try:
                GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, sig, self.quit)
            except Exception:
                pass
        self.timer = GLib.timeout_add(self.interval, self.tick)

    # ---------- 指针 ----------
    def pointer(self):
        try:
            dev = Gdk.Display.get_default().get_default_seat().get_pointer()
            res = dev.get_position()
            return res[1], res[2]
        except Exception:
            return None, None

    # ---------- 发射 ----------
    def emit_along(self, x, y, dx, dy, dist):
        if not self.cfg.get('enabled', True) or self.eff == 'off':
            return
        sz = float(self.cfg.get('size', 1.0))
        dens = float(self.cfg.get('density', 1.0))
        step = max(5.0, 11.0 / max(0.35, dens))
        n = int(dist / step) + 1
        if n > 8:
            n = 8
        # 快速移动: 提高间距/减少数量(视觉几乎无差别, 但 CPU 明显下降)
        sp = getattr(self, 'speed', 0.0)
        if sp > 2500.0:
            step = max(step, 18.0)
            n = min(n, 3)
        elif sp > 1200.0:
            step = max(step, 14.0)
            n = min(n, 5)
        eff = self.eff
        for i in range(n):
            f = (i + 1) / float(n)
            k = self.cur_kind if eff == 'auto' else eff
            self.ps.emit(k, x + dx * f, y + dy * f, dx, dy, dist, sz, dens)

    def push_trail(self, x, y, now):
        self.trail.append((x, y, now))
        while len(self.trail) > 64:
            self.trail.pop(0)
        old = now - 0.55
        while self.trail and self.trail[0][2] < old:
            self.trail.pop(0)
        self.trail_pts = [(p[0], p[1]) for p in self.trail]

    # ---------- 主循环 ----------
    def tick(self):
        now = time.time()
        dt = now - self.pt if self.pt else 0.02
        if dt <= 0.0 or dt > 0.25:
            dt = 0.02
        self.pt = now
        self.hue_base = (now * 0.12) % 1.0

        mx, my = self.pointer()
        moved = False
        if mx is not None:
            if self.px is not None:
                dx = mx - self.px
                dy = my - self.py
                dist = math.hypot(dx, dy)
                if dist >= 2.0:
                    moved = True
                    self.speed = dist / max(0.001, dt)
                    self.emit_along(self.px, self.py, dx, dy, dist)
                    self.push_trail(mx, my, now)
            else:
                self.speed = 0.0
            self.px, self.py = mx, my

        if self.eff == 'auto':
            if now >= self.auto_until:
                self.auto_kind = random.choice(AUTO_POOL)
                self.auto_until = now + random.uniform(1.6, 3.2)
            self.cur_kind = self.auto_kind
        else:
            self.cur_kind = self.eff

        if self.ps.items:
            self.ps.update(dt)
        self.flush(now)
        self.adapt(moved)
        return True

    def flush(self, now):
        d = self.ps.take_dirty()
        if self.trail_pts and self.cur_kind in ('ribbon', 'rainbow'):
            xs = [p[0] for p in self.trail_pts]
            ys = [p[1] for p in self.trail_pts]
            m = 16.0 * float(self.cfg.get('size', 1.0)) + 6
            r = [min(xs) - m, min(ys) - m, max(xs) + m, max(ys) + m]
            if d is None:
                d = r
            else:
                d = [min(d[0], r[0]), min(d[1], r[1]), max(d[2], r[2]), max(d[3], r[3])]
        if d is None:
            if self.prev_rect is not None:
                self.overlay.invalidate(*self.prev_rect)
                self.prev_rect = None
            return
        if self.prev_rect is not None:
            p = self.prev_rect
            d = [min(d[0], p[0]), min(d[1], p[1]), max(d[2], p[2]), max(d[3], p[3])]
        self.overlay.invalidate(d[0] - 3, d[1] - 3, d[2] + 4, d[3] + 4)
        self.prev_rect = (d[0] - 3, d[1] - 3, d[2] + 4, d[3] + 4)

    def adapt(self, moved):
        n = len(self.ps.items)
        sp = getattr(self, 'speed', 0.0)
        # 高速移动时: 降低帧率并限制粒子总数(拖尾观感几乎不变, CPU 降一截)
        cap = int(self.cfg.get('max_particles', 150))
        fps_base = int(self.cfg.get('fps', 30))
        eco = bool(self.cfg.get('eco', True))
        if eco:
            fps_base = min(fps_base, 26)
        if sp > 4000.0:
            cap = max(24, int(cap * 0.28))
            fps_base = max(12, fps_base - 18)
        elif sp > 2500.0:
            cap = max(32, int(cap * 0.40))
            fps_base = max(14, fps_base - 14)
        elif sp > 1200.0:
            cap = max(42, int(cap * 0.58))
            fps_base = max(18, fps_base - 9)
        elif sp > 600.0 and eco:
            fps_base = max(20, fps_base - 4)
        try:
            self.ps.trim(cap)
        except Exception:
            pass
        if moved or n > 6:
            want = max(12, int(1000 / max(15, fps_base)))
            self.idle = 0
        elif n > 0:
            want = 45
            self.idle = 0
        else:
            self.idle += 1
            want = 120 if self.idle < 10 else (250 if self.idle < 60 else 400)
        if want != self.interval:
            self.interval = want
            if self.timer:
                GLib.source_remove(self.timer)
            self.timer = GLib.timeout_add(want, self.tick)

    # ---------- 托盘图标与菜单 ----------
    def make_icon(self):
        S = 32
        surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, S, S)
        cr = cairo.Context(surf)
        c = S / 2.0
        for rad, al, hue in ((14.5, 0.20, 0.58), (11.0, 0.30, 0.66), (8.5, 0.35, 0.13)):
            _circle(cr, c, c, rad)
            r, g, b = hsv(hue, 0.85, 1.0)
            cr.set_source_rgba(r, g, b, al)
            cr.fill()
        _star_path(cr, c, c, 12.5, 3.6, -1.5708, 4)
        r, g, b = hsv(0.13, 0.95, 1.0)
        cr.set_source_rgba(r, g, b, 1.0)
        cr.fill()
        _star_path(cr, c, c, 6.6, 1.9, -1.5708, 4)
        cr.set_source_rgba(1, 1, 1, 0.95)
        cr.fill()
        return Gdk.pixbuf_get_from_surface(surf, 0, 0, S, S)

    def build_tray(self):
        try:
            self.tray = Gtk.StatusIcon()
            self.tray.set_from_pixbuf(self.make_icon())
            self.tray.set_tooltip_text('%s — 右键打开菜单' % TITLE)
            self.tray.set_visible(True)
            self.tray.connect('popup-menu', self.on_tray_popup)
            self.tray.connect('activate', self.on_tray_activate)
        except Exception:
            self.tray = None

    def radio_menu(self, options, current, cb):
        sub = Gtk.Menu()
        group = None
        for val, name in options:
            it = Gtk.RadioMenuItem(label=name)
            if group is None:
                group = it
            else:
                it.join_group(group)
            if val == current:
                it.set_active(True)
            it.connect('toggled', self.on_radio, cb, val)
            sub.append(it)
        return sub

    def on_radio(self, item, cb, val):
        if item.get_active():
            cb(val)

    def build_menu(self):
        m = Gtk.Menu()

        it = Gtk.CheckMenuItem(label='启用特效')
        it.set_active(bool(self.cfg.get('enabled', True)))
        it.connect('toggled', self.on_enabled)
        m.append(it)

        sub = Gtk.MenuItem(label='特效选择')
        sub.set_submenu(self.radio_menu([(k, n) for k, n in EFFECTS],
                                        self.cfg.get('effect'), self.on_effect))
        m.append(sub)

        sub = Gtk.MenuItem(label='特效大小')
        sub.set_submenu(self.radio_menu([(0.6, '小'), (1.0, '中'), (1.6, '大'), (2.2, '超大')],
                                        self.cfg.get('size'), self.on_size))
        m.append(sub)

        sub = Gtk.MenuItem(label='粒子密度')
        sub.set_submenu(self.radio_menu([(0.5, '少'), (1.0, '中'), (1.8, '多'), (2.8, '很多')],
                                        self.cfg.get('density'), self.on_density))
        try:
            it_eco = Gtk.CheckMenuItem(label='省电模式（低占用）')
            it_eco.set_active(bool(self.cfg.get('eco', True)))
            it_eco.connect('toggled', self.on_eco)
            menu.append(it_eco)
        except Exception:
            pass
        m.append(sub)

        sub = Gtk.MenuItem(label='帧率上限')
        sub.set_submenu(self.radio_menu([(24, '省电 24'), (40, '流畅 40'), (60, '极流畅 60')],
                                        self.cfg.get('fps'), self.on_fps))
        m.append(sub)

        m.append(Gtk.SeparatorMenuItem())

        it = Gtk.CheckMenuItem(label='开机自动启动')
        it.set_active(autostart_enabled())
        it.connect('toggled', self.on_autostart)
        m.append(it)

        it = Gtk.MenuItem(label='关于')
        it.connect('activate', self.on_about)
        m.append(it)

        m.append(Gtk.SeparatorMenuItem())
        it = Gtk.MenuItem(label='退出')
        it.connect('activate', lambda w: self.quit())
        m.append(it)

        m.show_all()
        return m

    def on_tray_popup(self, icon, button, time):
        if self.tray_menu is None:
            self.tray_menu = self.build_menu()
        self.tray_menu.popup(None, None, Gtk.StatusIcon.position_menu,
                             icon, button, time)

    def on_tray_activate(self, icon):
        self.cfg['enabled'] = not bool(self.cfg.get('enabled', True))
        save_config(self.cfg)
        if self.tray_menu is not None:
            self.tray_menu = None

    def on_enabled(self, item):
        self.cfg['enabled'] = item.get_active()
        save_config(self.cfg)

    def on_effect(self, key):
        self.cfg['effect'] = key
        self.eff = key
        self.auto_until = 0.0
        self.trail = []
        self.trail_pts = []
        if key == 'off':
            self.ps.items = []
            self.ps.dirty = None
            self.overlay.invalidate(0, 0, self.overlay.sw, self.overlay.sh)
        save_config(self.cfg)

    def on_size(self, val):
        self.cfg['size'] = val
        save_config(self.cfg)

    def on_eco(self, item):
        self.cfg['eco'] = bool(item.get_active())
        save_config(self.cfg)
        try:
            self.ps.trim(int(self.cfg.get('max_particles', 150)))
        except Exception:
            pass

    def on_density(self, val):
        self.cfg['density'] = val
        save_config(self.cfg)

    def on_fps(self, val):
        self.cfg['fps'] = val
        save_config(self.cfg)

    def on_autostart(self, item):
        set_autostart(item.get_active())

    def on_about(self, item):
        d = Gtk.MessageDialog(None, 0, Gtk.MessageType.INFO, Gtk.ButtonsType.OK,
                              TITLE)
        d.format_secondary_text(
            '鼠标移动产生炫彩粒子拖尾，覆盖层点击穿透，不影响任何操作。\n\n'
            '特效：智能混合 / 烟雾 / 闪钻 / 星星 / 泡泡 / 丝带 / 彩虹 /\n'
            '      火焰 / 雪花 / 爱心 / 花瓣 / 星云 / 礼花\n\n'
            '低占用：静止时自动降频、只重绘脏区、粒子对象池复用。\n'
            '配置文件：~/.config/%s/config.json' % APP)
        d.run()
        d.destroy()

    def quit(self, *args):
        try:
            save_config(self.cfg)
        except Exception:
            pass
        Gtk.main_quit()
        return False


def main():
    if single_instance() is None:
        return
    first = not os.path.exists(CONFIG_PATH)
    cfg = load_config()
    if first:
        save_config(cfg)
        set_autostart(True)
    App(cfg)
    Gtk.main()


if __name__ == '__main__':
    main()
