#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""任务栏外观定制：把任务栏固定为纯黑/透明，托盘图标随之恒为白色，
   且不影响应用窗口的明暗。

做法：
 1. 在用户主题目录里维护一个自定义主题，把 DockBackground 固定为 #000000、
    DockOpacity 固定为 0（两个明暗变体都写死 → 永远不会变）。
 2. 外观设为该主题的浅色变体（应用窗口保持浅色），并关闭“自动切换外观”
    （Theme_Auto=false），从此任务栏不会随系统自动改色。
 3. 托盘/任务栏图标的颜色跟随任务栏底色，任务栏一黑，图标自动变白。
"""
import os
import re
import shutil
import subprocess
import sys

THEME_DIR = os.path.expanduser('~/.config/dde-appearance/deepin-themes/custom')
THEME_FILE = os.path.join(THEME_DIR, 'index.theme')
BACKUP = os.path.join(THEME_DIR, 'index.theme.bak')

DOCK_BG = '#000000'
DOCK_OP = '0'

DEFAULT_THEME = """[Deepin Theme]
Name=Custom
DefaultTheme=DefaultTheme
DarkTheme=DarkTheme

[DefaultTheme]
AppTheme=deepin
CursorTheme=bloom
DockBackground=#000000
DockOpacity=0
FontSize=12
IconTheme=nirvana
MonospaceFont=Noto Mono
StandardFont=Noto Sans
WindowOpacity=0.4
WindowRadius=12

[DarkTheme]
AppTheme=deepin-dark
CursorTheme=bloom
DockBackground=#000000
DockOpacity=0
FontSize=12
IconTheme=nirvana
MonospaceFont=Noto Mono
StandardFont=Noto Sans
WindowOpacity=0.4
WindowRadius=12
"""

WANT = {'DockBackground': DOCK_BG, 'DockOpacity': DOCK_OP}
SECTIONS = ('DefaultTheme', 'DarkTheme')


def patch_theme(text):
    """在 DefaultTheme / DarkTheme 两段里设置 DockBackground / DockOpacity"""
    out = []
    cur = None
    seen = {}
    for line in text.splitlines():
        m = re.match(r'\s*\[(.+?)\]\s*$', line)
        if m:
            if cur in SECTIONS:
                for k, v in WANT.items():
                    if not seen.get((cur, k)):
                        out.append('%s=%s' % (k, v))
            cur = m.group(1)
            out.append(line)
            continue
        mm = re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)\s*=', line)
        if mm and cur in SECTIONS:
            key = mm.group(1)
            if key in WANT:
                out.append('%s=%s' % (key, WANT[key]))
                seen[(cur, key)] = True
                continue
        out.append(line)
    if cur in SECTIONS:
        for k, v in WANT.items():
            if not seen.get((cur, k)):
                out.append('%s=%s' % (k, v))
    return '\n'.join(out) + '\n'


def run_dconfig(args):
    try:
        r = subprocess.run(['dde-dconfig'] + args, capture_output=True,
                           text=True, timeout=15)
        return r.returncode == 0, (r.stdout or r.stderr).strip()
    except Exception as e:
        return False, str(e)


def main():
    os.makedirs(THEME_DIR, exist_ok=True)
    if os.path.exists(THEME_FILE):
        if not os.path.exists(BACKUP):
            shutil.copy2(THEME_FILE, BACKUP)
        text = open(THEME_FILE, encoding='utf-8').read()
    else:
        text = DEFAULT_THEME
    new = patch_theme(text)
    if new != text or not os.path.exists(THEME_FILE):
        with open(THEME_FILE, 'w', encoding='utf-8') as f:
            f.write(new)
        print('✔ 任务栏配色已固定为纯黑/透明：%s' % THEME_FILE)
    else:
        print('· 任务栏配色已经是固定纯黑/透明')

    ok1, m1 = run_dconfig(['set', '-a', 'org.deepin.dde.appearance',
                           '-k', 'Theme_Auto', '-v', 'false'])
    print('   %s 关闭“自动切换外观”%s' % ('✔' if ok1 else '✘', '' if ok1 else ' ' + m1))
    ok2, m2 = run_dconfig(['set', '-a', 'org.deepin.dde.appearance',
                           '-k', 'Global_Theme', '-v', 'custom.light'])
    print('   %s 外观=Custom(浅色)：应用窗口保持浅色，任务栏始终纯黑、图标白色%s'
          % ('✔' if ok2 else '✘', '' if ok2 else ' ' + m2))
    print('   提示：想换深色应用窗口，可在 控制中心→个性化→外观 里选深色，'
          '任务栏不受影响。')
    return 0 if (ok1 and ok2) else 1


if __name__ == '__main__':
    sys.exit(main())
