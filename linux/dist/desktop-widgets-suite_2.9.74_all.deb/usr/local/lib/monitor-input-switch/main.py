#!/usr/bin/env python3
import sys as _wfsys
_wf_path = '/usr/local/lib/desktop-widgets-suite'
if _wf_path not in _wfsys.path:
    _wfsys.path.insert(0, _wf_path)
from widget_font import SYS_FONT as _SYS_FONT
# -*- coding: utf-8 -*-
"""显示器输入源切换 (鼠标侧键)
按配置的鼠标侧键: 一键切换显示器输入源 (本机DP <-> 另一台USB-C)
- 上侧键(默认按钮9): 切换到另一台电脑 (USB-C)
- 下侧键(默认按钮8): 切回本机 (DP)
基于 DDC/CI (ddcutil setvcp 0x60)
"""
import glob
import json
import os
import re
import struct
import subprocess
import time

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Pango', '1.0')
from gi.repository import Gtk, Gdk, GLib, Pango

APP_NAME = 'monitor-input-switch'
ICON_PATH = '/usr/local/share/icons/hicolor/128x128/apps/monitor-input-switch.png'
CONFIG_DIR = os.path.expanduser('~/.config/monitor-input-switch')
CONFIG_PATH = os.path.join(CONFIG_DIR, 'config.json')
PID_PATH = os.path.join(CONFIG_DIR, 'pid')

DEFAULT_CFG = {
    'button_switch_code': 276,  # 上侧键 evdev code (BTN_EXTRA): 切到另一台
    'button_back_code': 275,   # 下侧键 evdev code (BTN_SIDE): 切回本机
    'input_this': 0x0f,     # 本机输入源 (DisplayPort = 0x0F = 15)
    'input_other': 0x36,    # 另一台输入源 (USB-C = 0x36 = 54, 三星 LS27D80xU)
    'bus': 0,               # 0=自动检测
    'osd_show': True,
}

OSD_FONT = _SYS_FONT + ' 24'
OSD_BG = (0.06, 0.08, 0.12, 0.82)
OSD_FG = '#FFFFFF'

# 托盘菜单样式：白底黑字 + 与本套其它挂件一致的字号（12pt = 系统默认字号）
MENU_CSS = b'''
menu {
    background-color: #FFFFFF;
    background-image: none;
    color: #000000;
    border: 1px solid #B8B8B8;
    padding: 4px;
}
menu menuitem, menu checkmenuitem, menu radiomenuitem {
    color: #000000;
    font-size: 12pt;
    padding: 7px 14px;
}
menu menuitem:hover, menu checkmenuitem:hover, menu radiomenuitem:hover {
    background-color: #E4E9F2;
    color: #000000;
}
menu menuitem:disabled {
    color: #8A8A8A;
}
menu separator {
    background-color: #D8D8D8;
    min-height: 1px;
    margin: 5px 2px;
}
'''
_menu_css_added = False


def _apply_menu_style():
    """本进程的弹出菜单统一为白底黑字、正常字号"""
    global _menu_css_added
    if _menu_css_added:
        return
    try:
        prov = Gtk.CssProvider()
        prov.load_from_data(MENU_CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), prov,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        _menu_css_added = True
    except Exception as e:
        log('menu style: ' + str(e))


def log(msg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(os.path.join(CONFIG_DIR, 'app.log'), 'a') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' ' + str(msg) + '\n')
    except Exception:
        pass


def load_config():
    cfg = dict(DEFAULT_CFG)
    try:
        with open(CONFIG_PATH) as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    return cfg


def save_config(cfg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_PATH, 'w') as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def detect_bus():
    """自动检测 DDC/CI 显示器 I2C bus, 失败返回 None"""
    try:
        out = subprocess.run(['ddcutil', 'detect'], capture_output=True,
                             text=True, timeout=15).stdout
        m = re.search(r'I2C bus:\s*/dev/i2c-(\d+)', out)
        return int(m.group(1)) if m else None
    except Exception:
        return None


def set_input(bus, value):
    """通过 DDC/CI 设置输入源, 返回 (成功?, 错误信息)"""
    if bus:
        cmd = ['ddcutil', '--bus', str(bus), 'setvcp', '0x60', '0x%02x' % value]
    else:
        cmd = ['ddcutil', 'setvcp', '0x60', '0x%02x' % value]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        if r.returncode == 0:
            return True, ''
        return False, (r.stderr or r.stdout)[-200:]
    except Exception as e:
        return False, str(e)


def get_input(bus):
    """读取当前输入源, 返回值或 None"""
    if bus:
        cmd = ['ddcutil', '--bus', str(bus), 'getvcp', '0x60']
    else:
        cmd = ['ddcutil', 'getvcp', '0x60']
    try:
        out = subprocess.run(cmd, capture_output=True, text=True,
                             timeout=15).stdout
        m = re.search(r'sl=0x([0-9a-f]+)', out)
        return int(m.group(1), 16) if m else None
    except Exception:
        return None
class OSD(Gtk.Window):
    """屏幕中央悬浮提示"""

    def __init__(self):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.set_title('monitor-input-switch-osd')
        self.set_decorated(False)
        self.set_app_paintable(True)
        self.set_keep_above(True)
        self.set_accept_focus(False)
        self.set_can_focus(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_type_hint(Gdk.WindowTypeHint.NOTIFICATION)
        visual = self.get_screen().get_rgba_visual()
        if visual:
            self.set_visual(visual)
        self._box = Gtk.EventBox()
        self._box.override_background_color(Gtk.StateType.NORMAL,
                                            Gdk.RGBA(*OSD_BG))
        self._label = Gtk.Label()
        self._label.set_markup('<span foreground="%s" font="%s">　</span>'
                               % (OSD_FG, OSD_FONT))
        self._label.set_padding(24, 14)
        self._box.add(self._label)
        self.add(self._box)
        self._timer = None

    def show_msg(self, text):
        try:
            self._label.set_markup('<span foreground="%s" font="%s">%s</span>'
                                   % (OSD_FG, OSD_FONT, text))
            self.show_all()
            scr = self.get_screen()
            sw, sh = scr.get_width(), scr.get_height()
            w = max(280, self.get_allocated_width())
            h = max(60, self.get_allocated_height())
            self.move(max(0, (sw - w) // 2), max(0, (sh - h) // 3))
            self.show_all()
        except Exception as e:
            log('osd: ' + str(e))
        if self._timer:
            GLib.source_remove(self._timer)
        self._timer = GLib.timeout_add(1400, self._hide)

    def _hide(self):
        self.hide()
        self._timer = None
        return False


def find_mouse_events():
    """返回指针类（鼠标/触摸板）evdev 设备路径。

    侧键(BTN_EXTRA/BTN_SIDE)只出现在指针类设备上，所以按能力过滤即可。
    不能打开全部 event*：evdev 事件流是排他消费的，全开会吃掉键盘事件，
    导致 shot-ocr 等监听快捷键的程序收不到按键。
    """
    out = []
    for path in sorted(glob.glob('/dev/input/event*')):
        base = '/sys/class/input/%s/device' % os.path.basename(path)
        try:
            with open(os.path.join(base, 'capabilities/ev')) as f:
                ev = int(f.read().strip(), 16)
            with open(os.path.join(base, 'capabilities/rel')) as f:
                rel = int(f.read().strip(), 16)
        except Exception:
            continue
        if ev & 0x02 and (rel & 0x01 or rel & 0x02 or rel & 0x04):
            out.append(path)
    return out


class InputSwitch:
    def __init__(self):
        self.cfg = load_config()
        self.bus = int(self.cfg.get('bus') or 0) or detect_bus()
        self.osd = OSD()
        self.ind = None
        self._fds = []  # (fd, path)
        log('start: bus=%s this=0x%02x other=0x%02x code_switch=%s code_back=%s'
            % (self.bus, self.cfg.get('input_this'), self.cfg.get('input_other'),
               self.cfg.get('button_switch_code'), self.cfg.get('button_back_code')))

    # ─── evdev 事件解析 (定时轮询, 与检测工具同源) ───
    def _rescan(self):
        """移除失效设备并打开新出现的设备 (热插拔恢复)"""
        try:
            # 清理失效 fd
            alive = []
            for fd, path in self._fds:
                if os.path.exists(path):
                    alive.append((fd, path))
                else:
                    try:
                        os.close(fd)
                    except Exception:
                        pass
                    log('device gone: ' + path)
            self._fds = alive
            # 打开新设备
            have = {p for _, p in self._fds}
            for path in find_mouse_events():
                if path not in have:
                    try:
                        fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
                        self._fds.append((fd, path))
                        log('opened: ' + path)
                    except Exception:
                        pass
        except Exception as e:
            log('rescan: ' + str(e))

    def _poll(self):
        now = time.time()
        if now - getattr(self, '_last_rescan', 0) > 2:
            self._rescan()
            self._last_rescan = now
        try:
            for fd, path in list(self._fds):
                try:
                    while True:
                        data = os.read(fd, 64)
                        if not data:
                            break
                        buf = data
                        while len(buf) >= 24:
                            sec, usec, etype, code, value = struct.unpack('llHHi', buf[:24])
                            buf = buf[24:]
                            if etype == 1 and value == 1:  # EV_KEY 按下
                                log('key press code=%d (%s)' % (code, path))
                                self._on_button(code)
                except BlockingIOError:
                    continue
                except OSError:
                    # 设备失效, 移除并稍后重扫
                    try:
                        os.close(fd)
                    except Exception:
                        pass
                    self._fds = [(f, p) for f, p in self._fds if f != fd]
                except Exception as e:
                    log('poll %s: %s' % (path, e))
        except Exception as e:
            log('poll: ' + str(e))
        return True

    def _open_devices(self):
        for path in find_mouse_events():
            try:
                fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
                self._fds.append((fd, path))
                log('opened: ' + path)
            except Exception as e:
                log('open fail %s: %s' % (path, e))

    def _on_button(self, code):
        if code == int(self.cfg.get('button_switch_code', 276)):
            self._switch_to_other()
        elif code == int(self.cfg.get('button_back_code', 275)):
            self._switch_to_this()

    # ─── 切换 ───
    def _switch_to_other(self):
        v = self.cfg.get('input_other', 0x14)
        if isinstance(v, str):
            v = int(v, 0)
        ok, err = set_input(self.bus, v)
        log('switch to other(0x%02x): %s %s' % (v, ok, err))
        if ok:
            self._show('🖥 已切换到另一台电脑 (USB-C)')
        else:
            self._show('⚠ 切换失败: ' + err.strip()[:40])

    def _switch_to_this(self):
        v = self.cfg.get('input_this', 0x0f)
        if isinstance(v, str):
            v = int(v, 0)
        ok, err = set_input(self.bus, v)
        log('switch to this(0x%02x): %s %s' % (v, ok, err))
        if ok:
            self._show('🖥 已切换回本机 (DP)')
        else:
            self._show('⚠ 切换失败: ' + err.strip()[:40])

    def _show(self, text):
        if self.cfg.get('osd_show', True):
            self.osd.show_msg(text)

    # ─── 托盘 ───
    def _make_indicator(self):
        """用 Gtk.StatusIcon（与本套其它挂件一致）：
        菜单由本进程 GTK 渲染 → 字号跟随系统主题（不再是托盘那套小字号），白底黑字"""
        try:
            _apply_menu_style()
            menu = Gtk.Menu()

            ti = Gtk.MenuItem(label='🖥 显示器输入切换')
            ti.set_sensitive(False)
            menu.append(ti)
            menu.append(Gtk.SeparatorMenuItem())

            item_now = Gtk.MenuItem(label='当前: 查询输入源')
            item_now.connect('activate', lambda w: self._show_current())
            menu.append(item_now)
            item_switch = Gtk.MenuItem(label='切换到另一台电脑 (USB-C)')
            item_switch.connect('activate', lambda w: self._switch_to_other())
            menu.append(item_switch)
            item_back = Gtk.MenuItem(label='切回本机 (DP)')
            item_back.connect('activate', lambda w: self._switch_to_this())
            menu.append(item_back)

            menu.append(Gtk.SeparatorMenuItem())

            item_osd = Gtk.CheckMenuItem(label='显示OSD提示')
            item_osd.set_active(self.cfg.get('osd_show', True))
            item_osd.connect('toggled', self._toggle_osd)
            menu.append(item_osd)

            item_auto = Gtk.CheckMenuItem(label='开机自动启动')
            item_auto.set_active(self._autostart_enabled())
            item_auto.connect('toggled', self._toggle_autostart)
            menu.append(item_auto)

            menu.append(Gtk.SeparatorMenuItem())

            item_quit = Gtk.MenuItem(label='退出')
            item_quit.connect('activate', lambda w: Gtk.main_quit())
            menu.append(item_quit)

            menu.show_all()
            self.menu = menu
            icon = Gtk.StatusIcon()
            icon.set_from_icon_name(APP_NAME)
            if not icon.get_icon_name():
                icon.set_from_file(ICON_PATH)
            icon.set_tooltip_text('显示器输入切换 — 左键查询输入源，右键打开菜单')
            icon.connect('popup-menu', self._on_tray_popup)
            icon.connect('activate', lambda i: self._show_current())
            icon.set_visible(True)
            self.ind = icon
        except Exception as e:
            log('indicator: ' + str(e))

    def _on_tray_popup(self, icon, button, time):
        if getattr(self, 'menu', None) is not None:
            self.menu.popup(None, None, Gtk.StatusIcon.position_menu,
                            icon, button, time)

    def _show_current(self):
        v = get_input(self.bus)
        if v is None:
            self._show('⚠ 无法读取输入源')
            return
        names = {0x0e: 'DisplayPort-1', 0x0f: 'DisplayPort-2',
                 0x10: 'HDMI-1', 0x11: 'HDMI-2', 0x14: 'USB-C'}
        name = names.get(v, '0x%02x' % v)
        self._show('当前输入源: %s' % name)

    def _toggle_osd(self, item):
        self.cfg['osd_show'] = item.get_active()
        save_config(self.cfg)

    def _autostart_enabled(self):
        return os.path.exists(os.path.expanduser(
            '~/.config/autostart/monitor-input-switch.desktop'))

    def _toggle_autostart(self, enable):
        d = os.path.expanduser('~/.config/autostart')
        p = os.path.join(d, 'monitor-input-switch.desktop')
        if enable:
            os.makedirs(d, exist_ok=True)
            with open(p, 'w') as f:
                f.write('[Desktop Entry]\nType=Application\n'
                        'Name=Monitor Input Switch\n'
                        'Exec=/usr/bin/monitor-input-switch\n'
                        'X-GNOME-Autostart-enabled=true\n')
        else:
            try:
                os.remove(p)
            except Exception:
                pass

    # ─── 运行 ───
    def run(self):
        self._make_indicator()
        self._open_devices()
        if not self._fds:
            log('没有找到鼠标设备!')
        GLib.timeout_add(50, self._poll)
        Gtk.main()

    def shutdown(self):
        for fd, path in self._fds:
            try:
                os.close(fd)
            except Exception:
                pass
        self._fds = []


def _is_self_instance(pid):
    try:
        with open('/proc/%d/cmdline' % pid, 'rb') as f:
            return 'monitor-input-switch' in f.read().decode('utf-8', 'replace')
    except Exception:
        return False


def check_single():
    try:
        if os.path.exists(PID_PATH):
            with open(PID_PATH) as f:
                old = int(f.read().strip() or 0)
            if old and old != os.getpid() and _is_self_instance(old):
                os._exit(0)
    except Exception:
        pass
    try:
        with open(PID_PATH, 'w') as f:
            f.write(str(os.getpid()))
    except Exception:
        pass


def _ensure_autostart():
    try:
        d = os.path.expanduser('~/.config/autostart')
        p3 = os.path.join(d, 'monitor-input-switch.desktop')
        if not os.path.exists(p3):
            os.makedirs(d, exist_ok=True)
            with open(p3, 'w') as f:
                f.write('[Desktop Entry]\nType=Application\n'
                        'Name=Monitor Input Switch\n'
                        'Exec=/usr/local/bin/monitor-input-switch\n'
                        'X-GNOME-Autostart-enabled=true\n')
    except Exception:
        pass


def main():
    check_single()
    _ensure_autostart()
    InputSwitch().run()


if __name__ == '__main__':
    main()
