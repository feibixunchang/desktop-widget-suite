#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""桌面记账挂件 (GTK3 + Cairo/Pango)
布局: 月份行 / 本月收支汇总 / 支出分类占比 / 明细列表 / 底部操作
数据: 复用 ~/.local/share/desktop-widget/wallet_data.json (与旧版兼容)
"""
import csv
import datetime
import json
import os
import subprocess
import sys

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Pango', '1.0')
gi.require_version('PangoCairo', '1.0')
from gi.repository import Gtk, Gdk, GLib, Pango, PangoCairo
import cairo

APP = 'desktop-wallet'
DATA_PATH = os.path.expanduser('~/.local/share/desktop-widget/wallet_data.json')
CFG_DIR = os.path.expanduser('~/.config/desktop-wallet')
STATE_PATH = os.path.join(CFG_DIR, 'state.json')
PID_PATH = os.path.join(CFG_DIR, 'pid')
LOG_PATH = os.path.join(CFG_DIR, 'app.log')

FONT = 'FZSongHei-B07'
MIN_W, MIN_H = 540, 360
MAX_W, MAX_H = 1500, 1300
PAD = 14
HEAD_H = 48
SUM_H = 76          # 收支汇总区高(标签+数值两行, 留出行距后仍需容纳大字号)
CAT_H = 100         # 支出分类区高(标题+3行, 首行与标题留间距)
CAL_HDR = 36          # 星期行高度(与第一行日期留出明显间距)
CAL_ROWS = 6
CAL_CELL_H = 26          # 单元格高度(正方形高亮框用)
CAL_CELL_GAP = 4         # 行间距
CAL_H = CAL_HDR + CAL_ROWS * (CAL_CELL_H + CAL_CELL_GAP) + 8
FOOT_H = 46
ROW_H = 30
CORNER = 26

C_TEXT = (0.94, 0.95, 0.97)
C_DIM = (0.66, 0.70, 0.80)
C_HINT = (0.52, 0.57, 0.68)
C_IN = (0.32, 0.86, 0.46)
C_OUT = (0.98, 0.40, 0.36)
C_BAL = (0.42, 0.72, 1.0)
C_ACC = (0.98, 0.72, 0.18)
CAT_COLORS = [(0.98, 0.55, 0.25), (0.40, 0.72, 1.0), (0.45, 0.90, 0.60),
              (0.95, 0.45, 0.75), (0.85, 0.80, 0.35), (0.55, 0.85, 0.95),
              (0.75, 0.60, 0.95), (0.95, 0.65, 0.55)]


def log(msg):
    try:
        os.makedirs(CFG_DIR, exist_ok=True)
        with open(LOG_PATH, 'a') as f:
            f.write('%s %s\n' % (datetime.datetime.now().strftime('%m-%d %H:%M:%S'),
                                 msg))
    except Exception:
        pass


def norm_type(v):
    s = str(v or '').strip().lower()
    if s in ('in', 'income', '收入', '收', '入'):
        return 'in'
    return 'out'


def load_data():
    d = {'records': []}
    try:
        with open(DATA_PATH, encoding='utf-8') as f:
            d = json.load(f)
    except Exception:
        pass
    recs = d.get('records', [])
    for r in recs:
        r['type'] = norm_type(r.get('type'))
        try:
            r['amount'] = float(r.get('amount', 0))
        except Exception:
            r['amount'] = 0.0
        r['category'] = r.get('category') or '其他'
        r['note'] = r.get('note') or ''
        r['date'] = r.get('date') or ''
        r['id'] = str(r.get('id') or '')
    d['records'] = recs
    return d


def save_data(d):
    try:
        os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
        with open(DATA_PATH, 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log('save: %s' % e)


def load_state():
    st = {'x': None, 'y': None, 'w': 540, 'h': 470, 'locked': False,
          'month': '', 'sel': -1, 'fs': 13}
    try:
        with open(STATE_PATH, encoding='utf-8') as f:
            st.update(json.load(f))
    except Exception:
        pass
    st['w'] = max(MIN_W, min(MAX_W, int(st.get('w', 620))))
    st['h'] = max(MIN_H, min(MAX_H, int(st.get('h', 470))))
    if not st.get('month'):
        st['month'] = datetime.date.today().strftime('%Y-%m')
    return st


def save_state(st):
    try:
        os.makedirs(CFG_DIR, exist_ok=True)
        with open(STATE_PATH, 'w', encoding='utf-8') as f:
            json.dump(st, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def check_single():
    try:
        with open(PID_PATH) as f:
            old = int(f.read().strip())
        if os.path.exists('/proc/%d' % old):
            c = open('/proc/%d/cmdline' % old, 'rb').read().decode(errors='ignore')
            if APP in c or 'wallet.py' in c:
                sys.exit(0)
    except Exception:
        pass
    try:
        os.makedirs(CFG_DIR, exist_ok=True)
        with open(PID_PATH, 'w') as f:
            f.write(str(os.getpid()))
    except Exception:
        pass


class Wallet(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL, decorated=False)
        self.set_title(APP)
        self.set_icon_name('lobehub-wallet')
        self.set_keep_below(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_app_paintable(True)
        self.set_accept_focus(False)
        self.set_can_focus(False)
        vis = self.get_screen().get_rgba_visual()
        if vis is not None:
            self.set_visual(vis)
        self.st = load_state()
        self.data = load_data()
        self.w = int(self.st['w'])
        self.h = int(self.st['h'])
        self.x = self.st.get('x')
        self.y = self.st.get('y')
        self.month = self.st['month']
        # 是否跟随“今天”所在月份：默认跟随，跨天/跨月自动跳到当月；
        # 只有用户手动翻月才停止跟随，点“今天”重新跟随。
        self.follow_today = bool(self.st.get('follow_today', True))
        self.fs = int(self.st.get('fs', 13))
        self.sel = -1
        self.scroll = 0
        self.day_filter = None
        self.hover = None
        self.dragging = False
        self.resizing = False
        self.size_orig = None
        self.drag_start = None
        self.drag_orig = None
        self.corner_hover = False
        self._ad_done = False
        self.resize(self.w, self.h)
        if self.x is not None:
            self.move(int(self.x), int(self.y))
        self.connect('draw', self.on_draw)
        self.connect('button-press-event', self.on_press)
        self.connect('button-release-event', self.on_release)
        self.connect('motion-notify-event', self.on_motion)
        self.connect('leave-notify-event', self.on_leave)
        self.connect('scroll-event', self.on_scroll)
        self.connect('destroy', Gtk.main_quit)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK |
                        Gdk.EventMask.BUTTON_RELEASE_MASK |
                        Gdk.EventMask.POINTER_MOTION_MASK |
                        Gdk.EventMask.LEAVE_NOTIFY_MASK |
                        Gdk.EventMask.SCROLL_MASK |
                        Gdk.EventMask.SMOOTH_SCROLL_MASK)
        self.show_all()
        GLib.timeout_add(120, self._autofit_height)
        GLib.timeout_add(800, self._all_desktops)
        GLib.timeout_add_seconds(60, self._tick)

    # ── 固定到所有桌面(进程内, 不再起子进程) ──
    def _all_desktops(self):
        if not getattr(self, '_ad_done', False):
            try:
                win = self.get_window()
                wid = win.get_xid() if win else 0
                if wid:
                    from Xlib import display as _xd
                    _d = _xd.Display()
                    _w = _d.create_resource_object('window', wid)
                    _w.change_property(_d.intern_atom('_NET_WM_DESKTOP'),
                                       _d.intern_atom('CARDINAL'), 32,
                                       [0xFFFFFFFF])
                    _d.sync()
                    _d.close()
                    self._ad_done = True
            except Exception:
                pass
        return False

    def _tick(self):
        """跨天/跨月时刷新高亮；跟随状态下自动切到当月"""
        if getattr(self, 'follow_today', True):
            cm = datetime.date.today().strftime('%Y-%m')
            if self.month != cm:
                self.month = cm
                self.sel = -1
                self.day_filter = None
                self.scroll = 0
                self._save()
                self._autofit_height()
        self.queue_draw()
        return True

    # ── 数据 ──
    def month_records(self, use_filter=True):
        rs = [r for r in self.data['records']
              if (r.get('date') or '').startswith(self.month)]
        if use_filter and self.day_filter:
            ds = '%02d' % self.day_filter
            rs = [r for r in rs if (r.get('date') or '')[8:10] == ds]
        rs.sort(key=lambda r: (r.get('date') or ''), reverse=True)
        return rs

    def sums(self, recs):
        i = sum(r['amount'] for r in recs if r['type'] == 'in')
        o = sum(r['amount'] for r in recs if r['type'] == 'out')
        return i, o, i - o

    def cat_totals(self, recs):
        agg = {}
        for r in recs:
            if r['type'] == 'out':
                agg[r['category']] = agg.get(r['category'], 0.0) + r['amount']
        return sorted(agg.items(), key=lambda kv: -kv[1])

    def _autofit_height(self):
        """窗口高度随记录条数自动增减(超出屏幕则内部滚动)"""
        if not self.st.get('autoh', True) or self.resizing:
            return
        n = max(1, len(self.month_records(use_filter=False)))
        base = 56 + CAL_H + 6 + self._sum_h() + 6 + self._cat_h() + 6 + FOOT_H + 8
        need = base + n * ROW_H + 10
        cap = MAX_H
        try:
            mon = self.get_display().get_monitor_at_window(self.get_window())
            cap = min(MAX_H, max(MIN_H, mon.get_workarea().height - 60))
        except Exception:
            pass
        h = int(max(MIN_H, min(cap, need)))
        if abs(self.h - h) > 2:
            self.h = h
            self.resize(self.w, h)
            self._save()
            self.queue_draw()

    def _save(self):
        self.st['x'], self.st['y'] = self.get_position()
        self.st['w'], self.st['h'] = self.w, self.h
        self.st['month'] = self.month
        self.st['follow_today'] = bool(getattr(self, 'follow_today', True))
        self.st['fs'] = self.fs
        self.st['locked'] = self.st.get('locked', False)
        save_state(self.st)

    def shift_month(self, d):
        y, m = int(self.month[:4]), int(self.month[5:7])
        m += d
        while m < 1:
            m += 12
            y -= 1
        while m > 12:
            m -= 12
            y += 1
        self.month = '%04d-%02d' % (y, m)
        self.follow_today = False
        self.sel = -1
        self.day_filter = None
        self.scroll = 0
        self._save()
        self._autofit_height()
        self.queue_draw()

    def goto_now(self):
        self.month = datetime.date.today().strftime('%Y-%m')
        self.follow_today = True
        self.sel = -1
        self.day_filter = None
        self.scroll = 0
        self._save()
        self.queue_draw()

    # ── 版面 ──
    def _cat_h(self):
        """分类区高度: 基础 CAT_H, 大字号时按字号差加高, 保证三行不越出边框"""
        return CAT_H + max(0, (self.fs - 13) * 4)

    def _sum_h(self):
        """汇总区高度: 随字号自适应, 容纳 '标签(top8) + 行距12 + 数值 + 底14',
        避免大字号下数值压到边框(实测 13 号需 83px, 17 号需 95px)"""
        try:
            lab_h = self._measure('本月支出', self.fs - 2)[1]
            val_h = self._measure('1234.56', self.fs + 7, True)[1]
            return int(8 + lab_h + 12 + val_h + 14)
        except Exception:
            return 84 + max(0, self.fs - 13) * 3

    def _layout(self):
        w, h = self.w, self.h
        L = {}
        L['hdr'] = (6, 6, w - 12, 42)
        L['prev'] = (PAD, 12, 42, 28)
        # 顶部右侧“今天/已锁定”从右往左排，避免窄面板下互相重叠
        lock_w, today_w, nav_w = 84, 58, 42
        lock_x = w - PAD - lock_w
        today_x = lock_x - 6 - today_w
        next_x = today_x - 6 - nav_w
        # 日期区在两个箭头之间居中: 左缘 prev 右缘+留白, 右缘 next 左缘-留白
        date_x = PAD + nav_w + 8
        date_w = max(120, next_x - date_x - 8)
        L['date'] = (date_x, 12, date_w, 28)
        L['next'] = (next_x, 12, nav_w, 28)
        L['today'] = (today_x, 13, today_w, 26)
        L['lock'] = (lock_x, 16, lock_w, 22)
        L['cal'] = (6, 56, w - 12, CAL_H)
        y2 = 56 + CAL_H + 6
        L['sum'] = (6, y2, w - 12, self._sum_h())
        L['cat'] = (6, y2 + self._sum_h() + 6, w - 12, self._cat_h())
        ly = y2 + self._sum_h() + 6 + self._cat_h() + 6
        L['list_y'] = ly
        L['list_h'] = max(ROW_H, h - ly - FOOT_H - 8)
        fy = h - FOOT_H
        L['foot'] = (6, fy - 4, w - 12, FOOT_H)
        L['btn_add'] = (PAD + 2, fy + 7, 76, 32)
        L['btn_edit'] = (PAD + 84, fy + 7, 70, 32)
        L['btn_del'] = (PAD + 160, fy + 7, 70, 32)
        return L

    def _box(self, ctx, rect, alpha=0.20, r=10):
        """细线条方框(整块挂件保持透明, 不用底色)"""
        x, y, w, h = rect
        self._round(ctx, x + 0.5, y + 0.5, max(2, w - 1), max(2, h - 1), r)
        ctx.set_source_rgba(1, 1, 1, alpha)
        ctx.set_line_width(1)
        ctx.stroke()

    # ── 绘制工具 ──
    def _measure(self, txt, size, bold=False):
        lay = self.create_pango_layout(txt)
        fd = '%s %s%d' % (FONT, 'Bold ' if bold else '', size)
        lay.set_font_description(Pango.FontDescription.from_string(fd))
        return lay.get_pixel_size()

    def _ink_center(self, txt, size, bold=False):
        """返回 (墨迹中心 y, 墨迹高度), 相对 layout 顶部, 用于视觉对齐"""
        lay = self.create_pango_layout(txt)
        fd = '%s %s%d' % (FONT, 'Bold ' if bold else '', size)
        lay.set_font_description(Pango.FontDescription.from_string(fd))
        ink = lay.get_extents()[0]
        return (ink.y / float(Pango.SCALE),
                ink.height / float(Pango.SCALE))

    def _text(self, ctx, txt, x, y, maxw, size, color, alpha=1.0, bold=False,
              align='left'):
        lay = self.create_pango_layout(txt)
        fd = '%s %s%d' % (FONT, 'Bold ' if bold else '', size)
        lay.set_font_description(Pango.FontDescription.from_string(fd))
        lay.set_ellipsize(Pango.EllipsizeMode.END)
        lay.set_width(int(max(20, maxw) * Pango.SCALE))
        tw = lay.get_pixel_size()[0]
        if align == 'center':
            x = x + (maxw - min(tw, maxw)) / 2
        elif align == 'right':
            x = x + max(0, maxw - tw)
        ctx.set_source_rgba(0.05, 0.06, 0.09, 0.55 * alpha)
        ctx.move_to(x + 1, y + 1)
        PangoCairo.show_layout(ctx, lay)
        ctx.set_source_rgba(color[0], color[1], color[2], alpha)
        ctx.move_to(x, y)
        PangoCairo.show_layout(ctx, lay)
        return min(tw, maxw)

    def _round(self, ctx, x, y, w, h, r):
        ctx.new_path()
        ctx.arc(x + r, y + r, r, 3.1416, 1.5 * 3.1416)
        ctx.arc(x + w - r, y + r, r, 1.5 * 3.1416, 2 * 3.1416)
        ctx.arc(x + w - r, y + h - r, r, 0, 0.5 * 3.1416)
        ctx.arc(x + r, y + h - r, r, 0.5 * 3.1416, 3.1416)
        ctx.close_path()

    def _button(self, ctx, txt, rect, color, key):
        x, y, w, h = rect
        on = (self.hover == key)
        self._round(ctx, x, y, w, h, 8)
        if on:
            ctx.set_source_rgba(color[0], color[1], color[2], 0.22)
            ctx.fill_preserve()
        ctx.set_source_rgba(color[0], color[1], color[2], 0.80)
        ctx.set_line_width(1)
        ctx.stroke()
        self._text(ctx, txt, x, y + (h - self._measure(txt, self.fs)[1]) / 2,
                   w, self.fs, color, 1.0, align='center')

    def on_draw(self, wdg, ctx):
        try:
            self._draw(ctx)
        except Exception as e:
            log('draw: %s' % e)
        return False

    def _draw_cal(self, ctx, rect):
        """月历面板: 有记账的日期高亮, 点击某天只看那天的明细"""
        import calendar as _cal
        x, y, w, h = rect
        self._box(ctx, rect)
        cw = (w - 16) / 7.0
        for i, nm in enumerate('一二三四五六日'):
            self._text(ctx, nm, x + 8 + i * cw, y + 7, cw, self.fs - 2,
                       C_HINT, 0.95, align='center')
        # 星期行下面画一条淡分隔线, 与日期行拉开层次
        ctx.set_source_rgba(1, 1, 1, 0.10)
        ctx.set_line_width(1)
        ctx.move_to(x + 8, y + CAL_HDR - 8)
        ctx.line_to(x + w - 8, y + CAL_HDR - 8)
        ctx.stroke()
        try:
            first = datetime.date(int(self.month[:4]), int(self.month[5:7]), 1)
        except Exception:
            return
        n_days = _cal.monthrange(first.year, first.month)[1]
        start_col = first.weekday()
        rec_days = {}
        for r in self.data['records']:
            dv = r.get('date') or ''
            if dv.startswith(self.month) and len(dv) >= 10:
                try:
                    dnum = int(dv[8:10])
                except Exception:
                    continue
                rec_days[dnum] = rec_days.get(dnum, 0) + 1
        today = datetime.date.today()
        self._cal_cells = []
        for day in range(1, n_days + 1):
            idx = start_col + day - 1
            row, col = divmod(idx, 7)
            if row >= CAL_ROWS:
                break
            cx = x + 8 + col * cw
            cy = y + CAL_HDR + row * (CAL_CELL_H + CAL_CELL_GAP)
            self._cal_cells.append((cx, cy, cw, CAL_CELL_H, day))
            sq = CAL_CELL_H - 4          # 正方形高亮框边长
            sx0 = cx + (cw - sq) / 2.0
            sy0 = cy + (CAL_CELL_H - sq) / 2.0
            has = day in rec_days
            sel = (self.day_filter == day)
            is_today = (today.year == first.year and today.month == first.month
                        and today.day == day)
            if sel or has:
                self._round(ctx, sx0, sy0, sq, sq, 6)
                if sel:
                    ctx.set_source_rgba(0.42, 0.72, 1.0, 0.42)
                else:
                    ctx.set_source_rgba(0.98, 0.72, 0.18, 0.26)
                ctx.fill()
            if is_today:
                self._round(ctx, sx0, sy0, sq, sq, 6)
                ctx.set_source_rgba(1, 1, 1, 0.55)
                ctx.set_line_width(1)
                ctx.stroke()
            col_t = C_ACC if (has and not sel) else (C_BAL if sel else
                    (C_TEXT if is_today else C_HINT))
            _tw, _th = self._measure(str(day), self.fs - 2)
            self._text(ctx, str(day), cx, sy0 + (sq - _th) / 2.0, cw,
                       self.fs - 2, col_t, 1.0, align='center')

    def _cal_hit(self, x, y):
        for (cx, cy, cw, ch, day) in getattr(self, '_cal_cells', []):
            if cx <= x <= cx + cw and cy <= y <= cy + ch:
                return day
        return None

    def _draw(self, ctx):
        w, h = self.w, self.h
        ctx.set_operator(cairo.OPERATOR_CLEAR)
        ctx.paint()
        ctx.set_operator(cairo.OPERATOR_OVER)
        # 整块挂件透明(与其它挂件一致), 各区块只用细线框勾勒

        L = self._layout()
        recs = self.month_records()
        inc, out, bal = self.sums(recs)

        # ── 第一行: 完整年月日(星期) + 可拖动/已锁定
        self._box(ctx, L['hdr'])
        today = datetime.date.today()
        is_now = (self.month == today.strftime('%Y-%m'))
        if is_now:
            d = today
        else:
            d = datetime.date(int(self.month[:4]), int(self.month[5:7]), 1)
        week = '一二三四五六日'[d.weekday()]
        date_txt = '%d年%d月%d日 星期%s' % (d.year, d.month, d.day, week)
        # 顶部日期按可用宽度自动缩字号，避免“星期…”被省略号截断
        dw = L['date'][2]
        dsize = self.fs + 2
        while dsize > self.fs - 3 and self._measure(date_txt, dsize, True)[0] > dw:
            dsize -= 1
        # 箭头与日期按“墨迹中心”对齐, 保证 ◀ ▶ 与文字在同一水平线上
        date_y = L['date'][1] + max(0, (L['date'][3] -
                                         self._measure(date_txt, dsize, True)[1]) / 2)
        _dc, _dh_ink = self._ink_center(date_txt, dsize, True)
        date_mid = date_y + _dc + _dh_ink / 2.0
        for _k, _ch, _col in (('prev', '◀',
                               (1, 1, 1) if self.hover == 'prev' else C_DIM),
                              ('next', '▶',
                               (1, 1, 1) if self.hover == 'next' else C_DIM)):
            _bx, _by, _bw, _bh = L[_k]
            _ac, _ah_ink = self._ink_center(_ch, dsize, True)
            _ay = date_mid - _ac - _ah_ink / 2.0
            _ay = max(_by - 6, min(_ay, _by + _bh))
            self._text(ctx, _ch, _bx, _ay, _bw, dsize, _col, 1.0,
                       bold=True, align='center')
        self._text(ctx, date_txt, L['date'][0], date_y, dw,
                   dsize, C_TEXT if is_now else C_ACC, 1.0, bold=True)
        self._button(ctx, '今天', L['today'], C_BAL, 'today')
        self._text(ctx, '已锁定' if self.st.get('locked') else '可拖动',
                   L['lock'][0], L['lock'][1] + 1, L['lock'][2], self.fs - 2,
                   C_HINT, 0.8, align='right')

        # ── 月历面板
        self._draw_cal(ctx, L['cal'])

        # ── 本月收支汇总
        sx, sy, sw, sh = L['sum']
        self._box(ctx, L['sum'])
        third = sw / 3.0
        items = [('本月支出', out, C_OUT), ('本月收入', inc, C_IN),
                 ('本月结余', bal, C_BAL)]
        # 标签占高(随字号自适应), 数值在其下方留出明显行距, 不再与标签贴在一起
        lab_h = self._measure(items[0][0], self.fs - 2)[1]
        for i, (lab, val, col) in enumerate(items):
            bx = sx + i * third
            self._text(ctx, lab, bx, sy + 8, third, self.fs - 2, C_DIM, 0.95,
                       align='center')
            txt = '%s%.2f' % ('-' if (i == 2 and val < 0) else
                              ('' if i == 0 else ('+' if val > 0 and i == 1 else '')),
                              abs(val) if i == 2 else val)
            val_y = sy + 8 + lab_h + 12
            self._text(ctx, txt, bx, val_y, third, self.fs + 7, col, 1.0,
                       bold=True, align='center')

        # ── 支出分类占比 (有支出才画)
        cx, cy, cw, ch = L['cat']
        self._box(ctx, L['cat'])
        self._text(ctx, '本月支出分类', cx + 10, cy + 4, cw - 20, self.fs - 2,
                   C_DIM, 0.95)
        # 分类行与标题之间按标题实际占高留出明显行距, 不再与标题贴在一起
        row0 = cy + 4 + self._measure('本月支出分类', self.fs - 2)[1] + 12
        cats = self.cat_totals(recs)
        if not cats:
            self._text(ctx, '本月还没有支出记录', cx + 10, row0, cw - 20, self.fs,
                       C_HINT, 0.8)
        else:
            total = sum(v for _, v in cats) or 1.0
            top = cats[:3]
            other = total - sum(v for _, v in top)
            if other > 0.005 and len(cats) > 3:
                top = top + [('其它 %d 项' % (len(cats) - 3), other)]
            bar_x = cx + 76
            bar_w = max(80, cw - 76 - 108)
            for i, (name, val) in enumerate(top):
                ry = row0 + i * 22
                col = CAT_COLORS[i % len(CAT_COLORS)]
                self._text(ctx, name, cx, ry, 74, self.fs - 1, C_TEXT, 0.95)
                self._round(ctx, bar_x, ry + 3, bar_w, 10, 5)
                ctx.set_source_rgba(1, 1, 1, 0.07)
                ctx.fill()
                self._round(ctx, bar_x, ry + 3, max(6, bar_w * val / total), 10, 5)
                ctx.set_source_rgba(col[0], col[1], col[2], 0.85)
                ctx.fill()
                self._text(ctx, '%.0f%%  ¥%.0f' % (val * 100.0 / total, val),
                           cx + cw - 104, ry, 104, self.fs - 1, col, 0.95,
                           align='right')

        # ── 明细列表
        ly, lh = L['list_y'], L['list_h']
        self._box(ctx, (6, ly - 3, w - 12, lh + 6))
        ctx.save()
        ctx.rectangle(PAD - 2, ly, w - 2 * (PAD - 2), lh)
        ctx.clip()
        if not recs:
            self._text(ctx, '本月还没有记录 · 点左下「添加」',
                       PAD + 6, ly + 10, w - 2 * PAD - 12, self.fs, C_HINT, 0.85)
        self._rows = []
        yy = ly + 2 - self.scroll
        for i, r in enumerate(recs):
            if yy + ROW_H < ly - 2:
                yy += ROW_H
                continue
            if yy > ly + lh:
                break
            self._rows.append((yy, yy + ROW_H, i))
            if i == self.sel:
                self._round(ctx, PAD - 2, yy, w - 2 * (PAD - 2), ROW_H - 2, 6)
                ctx.set_source_rgba(0.35, 0.65, 1.0, 0.22)
                ctx.fill()
            col = C_IN if r['type'] == 'in' else C_OUT
            sign = '+' if r['type'] == 'in' else '-'
            d = r.get('date', '')
            self._text(ctx, d[5:] if len(d) >= 10 else d, PAD + 2, yy + 5, 70,
                       self.fs - 1, C_DIM, 0.95)
            self._text(ctx, r['category'], PAD + 76, yy + 5, 80, self.fs, C_TEXT,
                       0.97)
            note_w = max(40, (w - PAD - 138) - (PAD + 160) - 8)
            self._text(ctx, r.get('note', ''), PAD + 160, yy + 5, note_w,
                       self.fs, C_DIM, 0.9)
            self._text(ctx, '%s%.2f' % (sign, r['amount']), w - PAD - 138,
                       yy + 5, 134, self.fs, col, 1.0, bold=True, align='right')
            yy += ROW_H
        ctx.restore()
        # 滚动条
        content_h = len(recs) * ROW_H
        if content_h > lh:
            frac = min(1.0, (self.scroll + lh) / float(content_h))
            bh = max(24, lh * lh / float(content_h))
            by = ly + (lh - bh) * min(1.0, self.scroll /
                                      float(max(1, content_h - lh)))
            self._round(ctx, w - 8, by, 4, bh, 2)
            ctx.set_source_rgba(0.75, 0.78, 0.85, 0.35)
            ctx.fill()

        # ── 底部: 操作按钮 + 计数
        fy = h - FOOT_H
        self._box(ctx, L['foot'])
        self._button(ctx, '添加', L['btn_add'], C_IN, 'add')
        self._button(ctx, '编辑', L['btn_edit'], C_ACC, 'edit')
        self._button(ctx, '删除', L['btn_del'], C_OUT, 'del')
        # 统计行起点跟随“删除”按钮右缘，窄面板下也能拿到全部剩余宽度
        ix = L['btn_del'][0] + L['btn_del'][2] + 8
        iw = max(60, w - 8 - ix)
        # 文案按“完整 → 精简”依次尝试：先缩字号，仍放不下才去掉前缀
        plain = '共 %d 笔 · 支出 ¥%.2f' % (len(recs), out)
        cands = ['当日 · ' + plain, plain] if self.day_filter else [plain]
        size = self.fs - 1
        info = cands[0]
        while size > self.fs - 5 and self._measure(info, size)[0] > iw:
            size -= 1
        if self._measure(info, size)[0] > iw and len(cands) > 1:
            info = cands[1]
            size = self.fs - 1
            while size > self.fs - 5 and self._measure(info, size)[0] > iw:
                size -= 1
        _th = self._measure(info, size)[1]
        self._text(ctx, info, ix, fy + (FOOT_H - _th) / 2, iw, size,
                   C_DIM, 0.95, align='center')
        # 缩放柄
        if not self.st.get('locked') or True:
            ctx.move_to(w - CORNER + 9, h - 6)
            ctx.line_to(w - 6, h - CORNER + 9)
            ctx.set_line_width(2)
            ctx.set_source_rgba(0.75, 0.78, 0.85,
                                0.55 if self.corner_hover else 0.25)
            ctx.stroke()

    # ── 命中测试 ──
    def _hit(self, x, y):
        L = self._layout()
        for k in ('prev', 'next', 'today'):
            bx, by, bw, bh = L[k]
            if bx <= x <= bx + bw and by <= y <= by + bh:
                return k
        bx, by, bw, bh = L['date']
        if bx <= x <= bx + bw and by <= y <= by + bh:
            return 'now'
        for k in ('add', 'edit', 'del'):
            bx, by, bw, bh = L['btn_' + k]
            if bx <= x <= bx + bw and by <= y <= by + bh:
                return k
        return None

    def _hit_row(self, x, y):
        ly = self._layout()['list_y']
        if y < ly:
            return None
        for y0, y1, i in getattr(self, '_rows', []):
            if y0 <= y <= y1:
                return i
        return None

    # ── 事件 ──
    def on_press(self, wdg, ev):
        x, y = int(ev.x), int(ev.y)
        if ev.button == 3:
            self._menu(ev)
            return True
        if ev.button != 1:
            return False
        # 角部缩放(锁定也允许缩放, 锁定只锁移动)
        if x >= self.w - CORNER and y >= self.h - CORNER:
            self.resizing = True
            self.size_orig = (self.w, self.h, int(ev.x_root), int(ev.y_root))
            self._cursor('nwse-resize')
            return True
        _d = self._cal_hit(x, y)
        if _d is not None:
            self.day_filter = None if self.day_filter == _d else _d
            self.sel = -1
            self.scroll = 0
            self.hover = None
            self.queue_draw()
            return True
        k = self._hit(x, y)
        if k == 'prev':
            self.shift_month(-1)
            return True
        if k == 'next':
            self.shift_month(1)
            return True
        if k == 'now' or k == 'today':
            self.goto_now()
            return True
        if k == 'add':
            self._edit_dialog(None)
            return True
        if k == 'edit':
            if 0 <= self.sel < len(self.month_records()):
                self._edit_dialog(self.month_records()[self.sel])
            return True
        if k == 'del':
            self._delete()
            return True
        idx = self._hit_row(x, y)
        if idx is not None:
            now = GLib.get_monotonic_time()
            if self.sel == idx and now - getattr(self, '_last_click', 0) < 400000:
                self._edit_dialog(self.month_records()[idx])
                self._last_click = 0
                return True
            self._last_click = now
            self.sel = idx
            self.queue_draw()
            return True
        if not self.st.get('locked'):
            self.dragging = True
            self.drag_start = (int(ev.x_root), int(ev.y_root))
            self.drag_orig = self.get_position()
        return True

    def on_release(self, wdg, ev):
        if self.resizing:
            self._cursor(None)
        if self.dragging or self.resizing:
            self._save()
        self.dragging = False
        self.resizing = False
        return False

    def on_motion(self, wdg, ev):
        x, y = int(ev.x), int(ev.y)
        if self.resizing and self.size_orig:
            nw = max(MIN_W, min(MAX_W, self.size_orig[0] + int(ev.x_root)
                                - self.size_orig[2]))
            nh = max(MIN_H, min(MAX_H, self.size_orig[1] + int(ev.y_root)
                                - self.size_orig[3]))
            self.w, self.h = int(nw), int(nh)
            self.resize(self.w, self.h)
            return True
        if self.dragging and self.drag_start:
            dx = int(ev.x_root) - self.drag_start[0]
            dy = int(ev.y_root) - self.drag_start[1]
            self.move(self.drag_orig[0] + dx, self.drag_orig[1] + dy)
            return True
        corner = (x >= self.w - CORNER and y >= self.h - CORNER)
        if corner != self.corner_hover:
            self.corner_hover = corner
            self._cursor('nwse-resize' if corner else None)
            self.queue_draw()
        k = self._hit(x, y)
        if k != self.hover:
            self.hover = k
            self.queue_draw()
        return False

    def on_leave(self, wdg, ev):
        self.hover = None
        self.corner_hover = False
        self._cursor(None)
        self.queue_draw()
        return False

    def on_scroll(self, wdg, ev):
        x, y = int(ev.x), int(ev.y)
        if y < self._layout()['list_y']:
            if ev.direction == Gdk.ScrollDirection.UP:
                self.shift_month(-1)
            elif ev.direction == Gdk.ScrollDirection.DOWN:
                self.shift_month(1)
            return True
        lh = self._layout()['list_h']
        content = len(self.month_records()) * ROW_H
        maxs = max(0, content - lh)
        if ev.direction == Gdk.ScrollDirection.UP:
            self.scroll = max(0, self.scroll - ROW_H * 3)
        elif ev.direction == Gdk.ScrollDirection.DOWN:
            self.scroll = min(maxs, self.scroll + ROW_H * 3)
        elif ev.direction == Gdk.ScrollDirection.SMOOTH:
            self.scroll = min(maxs, max(0, self.scroll + int(ev.delta_y * 60)))
        self.queue_draw()
        return True

    def _cursor(self, name=None):
        try:
            win = self.get_window()
            if win is None:
                return
            cur = Gdk.Cursor.new_from_name(self.get_display(), name) if name else None
            win.set_cursor(cur)
        except Exception:
            pass

    # ── 记一笔 / 编辑 ──
    def _edit_dialog(self, rec=None):
        dlg = Gtk.Dialog(title=('编辑记录' if rec else '记一笔'),
                         transient_for=self)
        dlg.set_default_size(380, -1)
        dlg.set_resizable(False)
        box = dlg.get_content_area()
        box.set_spacing(8)
        for m in ('start', 'end'):
            getattr(box, 'set_margin_' + m)(14)
        box.set_margin_top(10)
        box.set_margin_bottom(6)
        grid = Gtk.Grid(row_spacing=8, column_spacing=8)
        box.add(grid)

        tcombo = Gtk.ComboBoxText()
        tcombo.append('out', '支出')
        tcombo.append('in', '收入')
        tcombo.set_active_id('in' if (rec and rec['type'] == 'in') else 'out')
        amt = Gtk.Entry()
        amt.set_width_chars(10)
        if rec:
            amt.set_text('%.2f' % rec['amount'])
        cat = Gtk.ComboBoxText.new_with_entry()
        for c in ['餐饮', '交通', '购物', '居住', '学习', '医疗', '娱乐', '人情',
                  '工资', '奖金', '理财', '其他']:
            cat.append_text(c)
        cat.get_child().set_text((rec or {}).get('category', '餐饮'))
        note = Gtk.Entry()
        note.set_text((rec or {}).get('note', ''))
        date = Gtk.Entry()
        date.set_text((rec or {}).get('date') or
                      max(datetime.date.today().isoformat(),
                          self.month + '-01'))
        rows = [('类型', tcombo), ('金额', amt), ('分类', cat),
                ('备注', note), ('日期(YYYY-MM-DD)', date)]
        for i, (lab, wd) in enumerate(rows):
            grid.attach(Gtk.Label(label=lab, xalign=0), 0, i, 1, 1)
            grid.attach(wd, 1, i, 1, 1)
        dlg.add_button('取消', Gtk.ResponseType.CANCEL)
        dlg.add_button('保存', Gtk.ResponseType.OK)
        dlg.show_all()
        resp = dlg.run()
        vals = (tcombo.get_active_id() or 'out',
                amt.get_text().strip(),
                cat.get_child().get_text().strip() or '其他',
                note.get_text().strip(),
                date.get_text().strip())
        dlg.destroy()
        if resp != Gtk.ResponseType.OK:
            return
        t, a, c, n, d = vals
        try:
            amount = abs(float(a))
        except Exception:
            self._msg('金额请填数字，例如 25.5')
            return
        if amount <= 0:
            self._msg('金额要大于 0')
            return
        try:
            datetime.date.fromisoformat(d)
        except Exception:
            self._msg('日期格式应为 2026-09-24')
            return
        if rec:
            rec.update({'type': t, 'amount': amount, 'category': c,
                        'note': n, 'date': d})
        else:
            self.data['records'].append(
                {'id': '%d%04d' % (int(GLib.get_monotonic_time()), 
                                   len(self.data['records'])),
                 'type': t, 'amount': amount, 'category': c, 'note': n,
                 'date': d})
            self.month = d[:7]
            self.follow_today = (self.month ==
                                 datetime.date.today().strftime('%Y-%m'))
            self.st['month'] = self.month
            self.scroll = 0
        save_data(self.data)
        self.sel = -1
        self._save()
        self._autofit_height()
        self.queue_draw()

    def _delete(self):
        recs = self.month_records()
        if not (0 <= self.sel < len(recs)):
            self._msg('先在列表里点选一条记录')
            return
        r = recs[self.sel]
        if self._ask('删除这条记录？\n\n%s  %s  ¥%.2f %s' %
                     (r['date'], r['category'], r['amount'], r.get('note', ''))):
            self.data['records'] = [x for x in self.data['records']
                                    if x.get('id') != r.get('id')]
            save_data(self.data)
            self.sel = -1
            self._autofit_height()
            self.queue_draw()

    def _export(self):
        recs = self.month_records()
        if not recs:
            self._msg('本月没有记录可导出')
            return
        path = os.path.expanduser('~/记账导出_%s.csv' % self.month)
        try:
            with open(path, 'w', newline='', encoding='utf-8-sig') as f:
                w = csv.writer(f)
                w.writerow(['日期', '类型', '分类', '金额', '备注'])
                for r in sorted(recs, key=lambda x: x.get('date', '')):
                    w.writerow([r.get('date', ''),
                                '收入' if r['type'] == 'in' else '支出',
                                r.get('category', ''), '%.2f' % r['amount'],
                                r.get('note', '')])
            self._msg('已导出 %d 条到：\n%s' % (len(recs), path))
        except Exception as e:
            self._msg('导出失败：%s' % e)

    def _msg(self, text):
        d = Gtk.MessageDialog(transient_for=self, modal=True,
                              message_type=Gtk.MessageType.INFO,
                              buttons=Gtk.ButtonsType.OK, text=text)
        d.run()
        d.destroy()

    def _ask(self, text):
        d = Gtk.MessageDialog(transient_for=self, modal=True,
                              message_type=Gtk.MessageType.QUESTION,
                              buttons=Gtk.ButtonsType.OK_CANCEL, text=text)
        ok = d.run() == Gtk.ResponseType.OK
        d.destroy()
        return ok

    # ── 右键菜单 ──
    def _menu(self, ev):
        m = Gtk.Menu()
        it = Gtk.CheckMenuItem(label='锁定位置（角部仍可缩放）')
        it.set_active(bool(self.st.get('locked')))
        it.connect('toggled', self._toggle_lock)
        m.append(it)
        ita = Gtk.CheckMenuItem(label='高度随条目自动增减')
        ita.set_active(bool(self.st.get('autoh', True)))
        ita.connect('toggled', self._toggle_autoh)
        m.append(ita)
        sub = Gtk.MenuItem(label='字号')
        sm = Gtk.Menu()
        for sz in (12, 13, 15, 17):
            i2 = Gtk.CheckMenuItem(label='%d 号' % sz)
            i2.set_active(self.fs == sz)
            i2.connect('activate', self._set_fs, sz)
            sm.append(i2)
        sub.set_submenu(sm)
        m.append(sub)
        m.append(Gtk.SeparatorMenuItem())
        i3 = Gtk.MenuItem(label='导出本月 CSV')
        i3.connect('activate', lambda *a: self._export())
        m.append(i3)
        it2 = Gtk.CheckMenuItem(label='开机自启')
        it2.set_active(os.path.exists(os.path.expanduser(
            '~/.config/autostart/desktop-wallet.desktop')))
        it2.connect('toggled', self._toggle_autostart)
        m.append(it2)
        m.append(Gtk.SeparatorMenuItem())
        i4 = Gtk.MenuItem(label='退出')
        i4.connect('activate', lambda *a: Gtk.main_quit())
        m.append(i4)
        m.show_all()
        m.popup(None, None, None, None, ev.button, ev.time)

    def _toggle_autoh(self, item):
        self.st['autoh'] = item.get_active()
        self._save()
        self._autofit_height()
        self.queue_draw()

    def _toggle_lock(self, item):
        self.st['locked'] = item.get_active()
        self._save()
        self.queue_draw()

    def _set_fs(self, item, sz):
        self.fs = sz
        self._save()
        self._autofit_height()
        self.queue_draw()

    def _toggle_autostart(self, item):
        p = os.path.expanduser('~/.config/autostart/desktop-wallet.desktop')
        if item.get_active():
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, 'w') as f:
                f.write('[Desktop Entry]\nType=Application\nName=桌面记账挂件\n'
                        'Exec=/usr/local/bin/desktop-wallet\n'
                        'X-GNOME-Autostart-enabled=true\nNoDisplay=true\n')
        else:
            try:
                os.remove(p)
            except Exception:
                pass


def main():
    check_single()
    Wallet()
    Gtk.main()


if __name__ == '__main__':
    main()
