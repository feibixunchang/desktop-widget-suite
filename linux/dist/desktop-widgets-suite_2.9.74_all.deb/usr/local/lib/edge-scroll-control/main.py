#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""屏幕边缘滚轮控制 (evdev 版, 无第三方依赖)
- 鼠标在屏幕最左侧边缘或任务栏区域: 滚轮调音量 (±5%)
- 鼠标在屏幕最右侧边缘: 滚轮调显示器亮度 (±5%)
- 屏幕中央 OSD 提示
"""
import ctypes
import ctypes.util
import glob
import json
import os
import re
import struct
import subprocess
import time

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Pango', '1.0')
from gi.repository import Gtk, Gdk, GLib, Pango

APP_NAME = 'edge-scroll-control'
ICON_PATH = '/usr/local/share/icons/hicolor/128x128/apps/edge-scroll-control.png'
CONFIG_DIR = os.path.expanduser('~/.config/edge-scroll-control')
CONFIG_PATH = os.path.join(CONFIG_DIR, 'config.json')
PID_PATH = os.path.join(CONFIG_DIR, 'pid')

# 由安装脚本/服务方式启动时环境里可能缺少音频会话变量, 会导致 pactl 连接失败
# (表现为滚轮调音量无反应、OSD 一直显示 0%), 这里补上当前用户的运行时目录
os.environ.setdefault('XDG_RUNTIME_DIR', '/run/user/%d' % os.getuid())
if not os.environ.get('PULSE_SERVER') and os.path.exists(
        '/run/user/%d/pulse/native' % os.getuid()):
    os.environ['PULSE_SERVER'] = 'unix:/run/user/%d/pulse/native' % os.getuid()

DEFAULT_CFG = {
    'left_edge': 4,
    'right_edge': 4,
    'dock_h': 74,
    'volume_step': 2,
    'brightness_step': 0.05,
    'brightness_min': 0.3,
    'brightness_max': 1.0,
    'enabled': True,
    'osd_show': True,
}

OSD_FONT = 'FZSongHei-B07 26'
OSD_BG = (0.06, 0.08, 0.12, 0.82)
OSD_FG = '#FFFFFF'

# 托盘菜单样式：白底黑字 + 与本套其它挂件一致的字号（12pt = 系统默认字号）
MENU_CSS = b'''
menu {
    background-color: #FFFFFF;
    background-image: none;
    color: #000000;
    border: 1px solid #B8B8B8;
    padding: 4px;
}
menu menuitem, menu checkmenuitem, menu radiomenuitem {
    color: #000000;
    font-size: 12pt;
    padding: 7px 14px;
}
menu menuitem:hover, menu checkmenuitem:hover, menu radiomenuitem:hover {
    background-color: #E4E9F2;
    color: #000000;
}
menu menuitem:disabled {
    color: #8A8A8A;
}
menu separator {
    background-color: #D8D8D8;
    min-height: 1px;
    margin: 5px 2px;
}
'''
_menu_css_added = False


def _apply_menu_style():
    """本进程的弹出菜单统一为白底黑字、正常字号"""
    global _menu_css_added
    if _menu_css_added:
        return
    try:
        prov = Gtk.CssProvider()
        prov.load_from_data(MENU_CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), prov,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        _menu_css_added = True
    except Exception as e:
        log('menu style: ' + str(e))

# evdev 常量
EV_REL = 2
REL_WHEEL = 8


def log(msg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(os.path.join(CONFIG_DIR, 'app.log'), 'a') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' ' + str(msg) + '\n')
    except Exception:
        pass


def load_config():
    cfg = dict(DEFAULT_CFG)
    try:
        with open(CONFIG_PATH) as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    return cfg


def save_config(cfg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_PATH, 'w') as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ─── 鼠标指针位置 (ctypes libX11, 无 python-xlib 依赖) ───
_libX11 = None


def _get_libX11():
    global _libX11
    if _libX11 is None:
        _libX11 = ctypes.CDLL(ctypes.util.find_library('X11'))
        _libX11.XOpenDisplay.restype = ctypes.c_void_p
        _libX11.XOpenDisplay.argtypes = [ctypes.c_char_p]
        _libX11.XDefaultRootWindow.restype = ctypes.c_ulong
        _libX11.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
        _libX11.XDisplayWidth.argtypes = [ctypes.c_void_p, ctypes.c_int]
        _libX11.XDisplayWidth.restype = ctypes.c_int
        _libX11.XDisplayHeight.argtypes = [ctypes.c_void_p, ctypes.c_int]
        _libX11.XDisplayHeight.restype = ctypes.c_int
        _libX11.XQueryPointer.argtypes = [ctypes.c_void_p, ctypes.c_ulong,
                                          ctypes.POINTER(ctypes.c_ulong),
                                          ctypes.POINTER(ctypes.c_ulong),
                                          ctypes.POINTER(ctypes.c_int),
                                          ctypes.POINTER(ctypes.c_int),
                                          ctypes.POINTER(ctypes.c_int),
                                          ctypes.POINTER(ctypes.c_int),
                                          ctypes.POINTER(ctypes.c_uint)]
        _libX11.XQueryPointer.restype = ctypes.c_int
    return _libX11


_dpy_cache = None


def _get_display():
    """复用同一个 X display 连接。

    XOpenDisplay 每次调用都会新建一条连接且不会自动释放，
    之前的写法每处理一次滚轮事件就泄漏一条连接，很快占满 X 的
    客户端名额（上限 256），导致其它程序再也打不开显示。
    """
    global _dpy_cache
    if _dpy_cache is None:
        _dpy_cache = _get_libX11().XOpenDisplay(None)
    return _dpy_cache


def get_pointer_xy():
    """返回鼠标指针的屏幕坐标 (x, y)"""
    try:
        x11 = _get_libX11()
        dpy = _get_display()
        if not dpy:
            return None
        root = x11.XDefaultRootWindow(dpy)
        rx = ctypes.c_ulong()
        ry = ctypes.c_ulong()
        wx = ctypes.c_int()
        wy = ctypes.c_int()
        rx_, ry_ = ctypes.c_int(), ctypes.c_int()
        mask = ctypes.c_uint()
        if x11.XQueryPointer(dpy, root, ctypes.byref(rx), ctypes.byref(ry),
                             ctypes.byref(rx_), ctypes.byref(ry_),
                             ctypes.byref(wx), ctypes.byref(wy),
                             ctypes.byref(mask)):
            return rx_.value, ry_.value
    except Exception:
        pass
    return None


# ─── 音量控制 ───
def get_volume():
    try:
        out = subprocess.run(['pactl', 'get-sink-volume', '@DEFAULT_SINK@'],
                             capture_output=True, text=True, timeout=5).stdout
        m = re.search(r'(\d+)%', out)
        return int(m.group(1)) if m else 0
    except Exception:
        try:
            out = subprocess.run(['amixer', 'get', 'Master'],
                                 capture_output=True, text=True, timeout=5).stdout
            m = re.search(r'\[(\d+)%\]', out)
            return int(m.group(1)) if m else 0
        except Exception:
            return 0


def set_volume(delta):
    try:
        op = '+%d%%' % abs(delta) if delta >= 0 else '-%d%%' % abs(delta)
        subprocess.run(['pactl', 'set-sink-volume', '@DEFAULT_SINK@', op],
                       check=False, timeout=5)
        return get_volume()
    except Exception:
        try:
            op = '%d%%+' % abs(delta) if delta >= 0 else '%d%%-' % abs(delta)
            subprocess.run(['amixer', 'set', 'Master', op], check=False, timeout=5)
            return get_volume()
        except Exception:
            return None


# ─── 亮度控制 ───
def get_outputs():
    try:
        out = subprocess.run(['xrandr', '--query'], capture_output=True,
                             text=True, timeout=5).stdout
        return [line.split()[0] for line in out.splitlines()
                if ' connected ' in line]
    except Exception:
        return []


def get_brightness(output):
    try:
        out = subprocess.run(['xrandr', '--verbose'], capture_output=True,
                             text=True, timeout=5).stdout
        cur = None
        for line in out.splitlines():
            if line.strip().startswith(output) and ' connected' in line:
                cur = 1.0
            elif cur is not None and 'Brightness' in line:
                m = re.search(r'Brightness:\s*([\d.]+)', line)
                if m:
                    return float(m.group(1))
            elif cur is not None and line.strip() and not line.startswith(' '):
                cur = None
        return 1.0
    except Exception:
        return 1.0


def set_brightness(output, value):
    value = max(0.1, min(1.0, value))
    try:
        subprocess.run(['xrandr', '--output', output, '--brightness', '%.2f' % value],
                       check=False, timeout=5)
        return value
    except Exception as e:
        log('set brightness: ' + str(e))
        return None
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第二部分: OSD + evdev 轮询控制 + 托盘"""


class OSD(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.set_decorated(False)
        self.set_app_paintable(True)
        self.set_keep_above(True)
        self.set_accept_focus(False)
        self.set_can_focus(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_type_hint(Gdk.WindowTypeHint.NOTIFICATION)
        visual = self.get_screen().get_rgba_visual()
        if visual:
            self.set_visual(visual)
        self._box = Gtk.EventBox()
        self._box.override_background_color(Gtk.StateType.NORMAL,
                                            Gdk.RGBA(*OSD_BG))
        self._label = Gtk.Label()
        self._label.set_markup('<span foreground="%s" font="%s">　</span>'
                               % (OSD_FG, OSD_FONT))
        self._label.set_padding(22, 12)
        self._box.add(self._label)
        self.add(self._box)
        self._timer = None

    def show_msg(self, text):
        try:
            self._label.set_markup('<span foreground="%s" font="%s">%s</span>'
                                   % (OSD_FG, OSD_FONT, text))
            self.show_all()
            scr = self.get_screen()
            sw, sh = scr.get_width(), scr.get_height()
            w = max(280, self.get_allocated_width())
            h = max(60, self.get_allocated_height())
            self.move(max(0, (sw - w) // 2), max(0, (sh - h) // 3))
            self.show_all()
        except Exception as e:
            log('osd: ' + str(e))
        if self._timer:
            GLib.source_remove(self._timer)
        self._timer = GLib.timeout_add(900, self._hide)

    def _hide(self):
        self.hide()
        self._timer = None
        return False


class EdgeControl:
    def __init__(self):
        self.cfg = load_config()
        self.outputs = get_outputs() or ['DEFAULT']
        self.brightness = get_brightness(self.outputs[0]) if self.outputs else 1.0
        self.osd = OSD()
        self.ind = None
        self._fds = []
        self._last_rescan = 0
        self._last_action_t = 0.0
        # 屏幕尺寸
        self.screen_w, self.screen_h = 1920, 1080
        try:
            geo = get_pointer_xy()
            if geo:
                dpy = _get_display()
                if dpy:
                    self.screen_w = _get_libX11().XDisplayWidth(dpy, 0)
                    self.screen_h = _get_libX11().XDisplayHeight(dpy, 0)
        except Exception:
            pass
        log('start: %dx%d outputs=%s brightness=%.2f' %
            (self.screen_w, self.screen_h, self.outputs, self.brightness))

    # ─── evdev 设备管理 ───
    def _all_devices(self):
        """只挑选指针类（鼠标/触摸板）设备。

        evdev 事件流是排他消费的：设备被一个进程读走后就读不到了。
        本程序只需要屏幕边缘滑动（EV_ABS/移动类），如果把全部 event*
        都打开会连带吃掉键盘事件，导致 shot-ocr 等监听快捷键的程序失效。
        """
        out = []
        for path in sorted(glob.glob('/dev/input/event*')):
            base = '/sys/class/input/%s/device' % os.path.basename(path)
            try:
                with open(os.path.join(base, 'capabilities/ev')) as f:
                    ev = int(f.read().strip(), 16)
                with open(os.path.join(base, 'capabilities/rel')) as f:
                    rel = int(f.read().strip(), 16)
            except Exception:
                continue
            if ev & 0x02 and (rel & 0x01 or rel & 0x02 or rel & 0x04):
                out.append(path)
        return out

    def _rescan(self):
        try:
            alive = []
            for fd, path in self._fds:
                if os.path.exists(path):
                    alive.append((fd, path))
                else:
                    try:
                        os.close(fd)
                    except Exception:
                        pass
            self._fds = alive
            have = {p for _, p in self._fds}
            for path in self._all_devices():
                if path not in have:
                    try:
                        fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
                        self._fds.append((fd, path))
                        log('opened: ' + path)
                    except Exception:
                        pass
        except Exception as e:
            log('rescan: ' + str(e))

    def _poll(self):
        now = time.time()
        if now - self._last_rescan > 2:
            self._rescan()
            self._last_rescan = now
        try:
            for fd, path in list(self._fds):
                try:
                    while True:
                        data = os.read(fd, 64)
                        if not data:
                            break
                        buf = data
                        while len(buf) >= 24:
                            sec, usec, etype, code, value = struct.unpack('llHHi', buf[:24])
                            buf = buf[24:]
                            if etype == EV_REL and code == REL_WHEEL and value != 0:
                                # 限流: 同一时刻只处理一次
                                if now - self._last_action_t > 0.1:
                                    self._on_wheel(1 if value > 0 else -1)
                                    self._last_action_t = now
                except BlockingIOError:
                    continue
                except OSError:
                    try:
                        os.close(fd)
                    except Exception:
                        pass
                    self._fds = [(f, p) for f, p in self._fds if f != fd]
                except Exception as e:
                    log('poll %s: %s' % (path, e))
        except Exception as e:
            log('poll: ' + str(e))
        return True

    # ─── 滚轮处理 ───
    def _on_wheel(self, direction):
        if not self.cfg.get('enabled', True):
            return
        try:
            x, y = get_pointer_xy()
            if x is None:
                return
        except Exception:
            return
        left = int(self.cfg.get('left_edge', 4))
        right = int(self.cfg.get('right_edge', 4))
        dock = int(self.cfg.get('dock_h', 74))
        if x >= self.screen_w - right:
            self._adjust_brightness(direction)
        elif x <= left or y >= self.screen_h - dock:
            self._adjust_volume(direction)

    def _adjust_volume(self, direction):
        step = int(self.cfg.get('volume_step', 5))
        v = set_volume(direction * step)
        if v is None:
            return
        self._show_osd('🔊 音量 %d%%' % v)

    def _adjust_brightness(self, direction):
        step = float(self.cfg.get('brightness_step', 0.05))
        bmin = float(self.cfg.get('brightness_min', 0.3))
        bmax = float(self.cfg.get('brightness_max', 1.0))
        b = self.brightness + direction * step
        b = max(bmin, min(bmax, round(b, 2)))
        if abs(b - self.brightness) < 0.001:
            return
        nb = set_brightness(self.outputs[0], b)
        if nb is None:
            return
        self.brightness = nb
        self._show_osd('☀ 亮度 %d%%' % round(nb * 100))

    def _show_osd(self, text):
        if self.cfg.get('osd_show', True):
            self.osd.show_msg(text)

    # ─── 托盘 ───
    def _make_indicator(self):
        """用 Gtk.StatusIcon（与本套其它挂件一致）：
        菜单由本进程 GTK 渲染 → 字号跟随系统主题（不再是托盘那套小字号），白底黑字"""
        try:
            _apply_menu_style()
            menu = Gtk.Menu()

            ti = Gtk.MenuItem(label='🖱 边缘滚轮控制')
            ti.set_sensitive(False)
            menu.append(ti)
            menu.append(Gtk.SeparatorMenuItem())

            item_en = Gtk.CheckMenuItem(label='启用边缘滚轮控制')
            item_en.set_active(self.cfg.get('enabled', True))
            item_en.connect('toggled', self._toggle_enabled)
            menu.append(item_en)

            item_osd = Gtk.CheckMenuItem(label='显示OSD提示')
            item_osd.set_active(self.cfg.get('osd_show', True))
            item_osd.connect('toggled', self._toggle_osd)
            menu.append(item_osd)

            item_auto = Gtk.CheckMenuItem(label='开机自动启动')
            item_auto.set_active(self._autostart_enabled())
            item_auto.connect('toggled', self._toggle_autostart)
            menu.append(item_auto)

            menu.append(Gtk.SeparatorMenuItem())

            item_quit = Gtk.MenuItem(label='退出')
            item_quit.connect('activate', lambda w: Gtk.main_quit())
            menu.append(item_quit)

            menu.show_all()
            self.menu = menu
            icon = Gtk.StatusIcon()
            icon.set_from_icon_name(APP_NAME)
            if not icon.get_icon_name():
                icon.set_from_file(ICON_PATH)
            icon.set_tooltip_text('边缘滚轮控制 — 左键开关，右键打开菜单')
            icon.connect('popup-menu', self._on_tray_popup)
            icon.connect('activate', self._on_tray_activate)
            icon.set_visible(True)
            self.ind = icon
        except Exception as e:
            log('indicator: ' + str(e))

    def _on_tray_popup(self, icon, button, time):
        if getattr(self, 'menu', None) is not None:
            self.menu.popup(None, None, Gtk.StatusIcon.position_menu,
                            icon, button, time)

    def _on_tray_activate(self, icon):
        self.cfg['enabled'] = not bool(self.cfg.get('enabled', True))
        save_config(self.cfg)
        if getattr(self, 'menu', None) is not None:
            for it in self.menu.get_children():
                if isinstance(it, Gtk.CheckMenuItem) and \
                        it.get_label().startswith('启用边缘滚轮'):
                    it.handler_block_by_func(self._toggle_enabled)
                    it.set_active(self.cfg['enabled'])
                    it.handler_unblock_by_func(self._toggle_enabled)
        self._show_osd('边缘滚轮控制：%s' % ('已开启' if self.cfg['enabled'] else '已关闭'))

    def _toggle_enabled(self, item):
        self.cfg['enabled'] = item.get_active()
        save_config(self.cfg)

    def _toggle_osd(self, item):
        self.cfg['osd_show'] = item.get_active()
        save_config(self.cfg)

    def _autostart_enabled(self):
        return os.path.exists(os.path.expanduser(
            '~/.config/autostart/edge-scroll-control.desktop'))

    def _toggle_autostart(self, enable):
        d = os.path.expanduser('~/.config/autostart')
        p = os.path.join(d, 'edge-scroll-control.desktop')
        if enable:
            os.makedirs(d, exist_ok=True)
            with open(p, 'w') as f:
                f.write('[Desktop Entry]\nType=Application\n'
                        'Name=Edge Scroll Control\n'
                        'Exec=/usr/local/bin/edge-scroll-control\n'
                        'X-GNOME-Autostart-enabled=true\n')
        else:
            try:
                os.remove(p)
            except Exception:
                pass

    # ─── 运行 ───
    def run(self):
        self._make_indicator()
        self._rescan()
        GLib.timeout_add(50, self._poll)
        Gtk.main()


def _is_self_instance(pid):
    try:
        with open('/proc/%d/cmdline' % pid, 'rb') as f:
            return 'edge-scroll-control' in f.read().decode('utf-8', 'replace')
    except Exception:
        return False


def check_single():
    try:
        if os.path.exists(PID_PATH):
            with open(PID_PATH) as f:
                old = int(f.read().strip() or 0)
            if old and old != os.getpid() and _is_self_instance(old):
                os._exit(0)
    except Exception:
        pass
    try:
        with open(PID_PATH, 'w') as f:
            f.write(str(os.getpid()))
    except Exception:
        pass


def _ensure_autostart():
    try:
        d = os.path.expanduser('~/.config/autostart')
        p2 = os.path.join(d, 'edge-scroll-control.desktop')
        if not os.path.exists(p2):
            os.makedirs(d, exist_ok=True)
            with open(p2, 'w') as f:
                f.write('[Desktop Entry]\nType=Application\n'
                        'Name=Edge Scroll Control\n'
                        'Exec=/usr/local/bin/edge-scroll-control\n'
                        'X-GNOME-Autostart-enabled=true\n')
    except Exception:
        pass


def main():
    check_single()
    _ensure_autostart()
    EdgeControl().run()


if __name__ == '__main__':
    main()
