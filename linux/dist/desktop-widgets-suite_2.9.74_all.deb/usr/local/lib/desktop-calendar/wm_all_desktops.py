#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""将指定名称的窗口设置为显示在所有桌面 (_NET_WM_DESKTOP = 0xFFFFFFFF)"""
import sys
import time
from Xlib import display as xdisplay

def main():
    name = sys.argv[1] if len(sys.argv) > 1 else ''
    time.sleep(1.5)
    try:
        d = xdisplay.Display()
        root = d.screen().root
        NET_WM_DESKTOP = d.intern_atom('_NET_WM_DESKTOP')
        CARDINAL = d.intern_atom('CARDINAL')
        ALL = 0xFFFFFFFF
        net_client_list = d.intern_atom('_NET_CLIENT_LIST')
        prop = root.get_full_property(net_client_list, CARDINAL)
        if prop:
            for wid in prop.value:
                try:
                    w = d.create_resource_object('window', wid)
                    wm_name = w.get_wm_name() or ''
                    wm_class = w.get_wm_class() or []
                    text = wm_name + ' ' + ' '.join(wm_class)
                    if name in text:
                        w.change_property(NET_WM_DESKTOP, CARDINAL, 32, [ALL])
                except Exception:
                    pass
        d.sync()
    except Exception:
        pass

if __name__ == '__main__':
    main()
