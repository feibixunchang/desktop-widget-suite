#!/usr/bin/env python3
from widget_font import SYS_FONT as _SYS_FONT
# -*- coding: utf-8 -*-
"""桌面系统监控挂件 - CPU/内存/网速/硬盘，透明背景可拖动可锁定"""
import json
import os
import re
import shutil
import subprocess
import sys
import time

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Pango', '1.0')
from gi.repository import Gtk, Gdk, Pango, GLib
import cairo

APP_DIR = os.path.dirname(os.path.abspath(__file__))
USER_DIR = os.path.expanduser('~/.local/share/desktop-widget/')
CONFIG_PATH = os.path.join(USER_DIR, 'monitor.json')
DEFAULT_FONT = _SYS_FONT + ''
BASE_FONT_SIZE = 24

LABEL_COLOR = '#FFEB3B'
VALUE_COLOR = '#87CEEB'
WHITE = '#FFFFFF'
DISK_LABEL_COLORS = {
    'C': '#FF6B6B',
    'D': '#FFA726',
    'U-231G': '#FFFFFF',
    'O-1T': '#FF5252',
}
DISK_NAME_MAP = {
    'SATA SSD': 'SATA',
    'USB Flash Drive': 'LKS',
    'D85C-EB30': 'LKS',
}


def log(msg):
    os.makedirs(USER_DIR, exist_ok=True)
    with open(os.path.join(USER_DIR, 'monitor.log'), 'a') as f:
        f.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' ' + str(msg) + '\n')


def load_config():
    cfg = {
        'x': None, 'y': None,
        'font_size': BASE_FONT_SIZE,
        'label_color': LABEL_COLOR,
        'value_color': VALUE_COLOR,
        'font': DEFAULT_FONT,
        'lock_position': False,
        'multi_line': False,
        'center_h': True,
    }
    if not os.path.exists(CONFIG_PATH):
        src = os.path.join(APP_DIR, 'monitor.json')
        if os.path.exists(src):
            try:
                os.makedirs(USER_DIR, exist_ok=True)
                shutil.copyfile(src, CONFIG_PATH)
            except Exception:
                pass
    try:
        with open(CONFIG_PATH) as f:
            cfg.update(json.load(f))
    except Exception as e:
        log('config load: ' + str(e))
    return cfg


def human(n):
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if n < 1024:
            return '%.1f%s' % (n, unit)
        n /= 1024
    return '%.1fPB' % n


class SystemMonitor:
    def __init__(self):
        self.cpu_prev = None
        self.net_prev = None
        self.ifaces = None
        self.model_map = {}
        self.model_ts = 0
        self.disk_info = None
        self.disk_info_ts = 0

    def _cpu_now(self):
        with open('/proc/stat') as f:
            parts = f.readline().split()[1:]
        total = sum(map(int, parts))
        idle = int(parts[3]) + int(parts[4])
        return total, idle

    def cpu_pct(self):
        now = self._cpu_now()
        if self.cpu_prev:
            dt = now[0] - self.cpu_prev[0]
            di = now[1] - self.cpu_prev[1]
            self.cpu_prev = now
            if dt > 0:
                return max(0.0, min(100.0, 100.0 * (1 - di / dt)))
        self.cpu_prev = now
        return 0.0

    def _net_now(self):
        rx = tx = 0
        with open('/proc/net/dev') as f:
            next(f)
            for line in f:
                m = re.match(r'\s*([^:]+):\s*(\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+)', line)
                if m:
                    iface = m.group(1)
                    if iface in ('lo',) or iface.startswith(('docker', 'veth', 'br-', 'virbr')):
                        continue
                    rx += int(m.group(2))
                    tx += int(m.group(3))
        return rx, tx

    def net_speed(self):
        now = self._net_now()
        if self.net_prev:
            d = (now[0] - self.net_prev[0], now[1] - self.net_prev[1])
            self.net_prev = now
            return (max(0, d[0]), max(0, d[1]))
        self.net_prev = now
        return (0, 0)

    def mem(self):
        total = avail = 0
        with open('/proc/meminfo') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    total = int(line.split()[1]) * 1024
                elif line.startswith('MemAvailable:'):
                    avail = int(line.split()[1]) * 1024
        used = max(0, total - avail)
        pct = 100.0 * used / total if total else 0
        return used, total, pct

    def disk(self):
        s = os.statvfs('/')
        total = s.f_frsize * s.f_blocks
        free = s.f_frsize * s.f_bavail
        used = total - free
        pct = 100.0 * used / total if total else 0
        return used, total, pct

    def _disk_models(self):
        now = time.time()
        if now - self.model_ts < 60:
            return self.model_map
        self.model_ts = now
        try:
            out = subprocess.run(
                ['lsblk', '-rno', 'NAME,TYPE,MODEL'], check=False,
                capture_output=True, text=True, timeout=5).stdout
            disks = {}
            for line in out.splitlines():
                parts = line.split(None, 2)
                if len(parts) < 2:
                    continue
                name, dtype = parts[0], parts[1]
                model = parts[2].strip() if len(parts) > 2 else ''
                if dtype == 'disk':
                    disks[name] = model or ''
                elif dtype == 'part':
                    parent = name.rstrip('0123456789')
                    if parent in disks:
                        disks[name] = disks[parent]
            self.model_map = {'/dev/%s' % k: v
                              for k, v in disks.items()}
        except Exception:
            pass
        return self.model_map

    def _mount_sources(self):
        sources = []
        try:
            with open('/proc/mounts') as f:
                for line in f:
                    parts = line.split()
                    if parts and parts[0].startswith('/dev/'):
                        sources.append(parts[0])
        except Exception:
            pass
        return tuple(sorted(set(sources)))

    def _disk_info(self):
        """构建 设备路径 -> (fstype, is_usb) 映射, 用于过滤 Windows 盘, 每次实时重扫"""
        self.disk_mount_sources = self._mount_sources()
        info = {}
        usb_disks = set()
        try:
            out = subprocess.run(
                ['lsblk', '-J', '-o', 'NAME,FSTYPE,TRAN,TYPE,PKNAME'], check=False,
                capture_output=True, text=True, timeout=5).stdout
            data = json.loads(out)

            def walk(devs):
                for d in devs or []:
                    yield d
                    yield from walk(d.get('children'))

            for d in walk(data.get('blockdevices')):
                t = d.get('type', '')
                if t == 'disk' and d.get('tran') == 'usb':
                    usb_disks.add(d.get('name', ''))
            for d in walk(data.get('blockdevices')):
                if d.get('type') == 'part':
                    info['/dev/%s' % d.get('name', '')] = (
                        d.get('fstype', ''), d.get('pkname', '') in usb_disks)
        except Exception as e:
            log('disk info: ' + str(e))
            info = None
        self.disk_info = info
        return info

    def _unmounted_usb(self):
        result = []
        try:
            out = subprocess.run(
                ['lsblk', '-J', '-b', '-o',
                 'NAME,TYPE,FSTYPE,TRAN,PKNAME,MODEL,SIZE,MOUNTPOINT'],
                check=False, capture_output=True, text=True, timeout=5).stdout
            data = json.loads(out)
            mounted = set()
            with open('/proc/mounts') as f:
                for line in f:
                    parts = line.split()
                    if parts and parts[0].startswith('/dev/'):
                        mounted.add(os.path.basename(os.path.realpath(parts[0])))

            def walk(devs):
                for d in devs or []:
                    yield d
                    yield from walk(d.get('children'))

            for d in walk(data.get('blockdevices')):
                if d.get('type') != 'disk':
                    continue
                if (d.get('tran') or '').lower() != 'usb':
                    continue
                name = d.get('name', '')
                if d.get('mountpoint'):
                    continue
                children = list(walk(d.get('children')))
                if name in mounted:
                    continue
                if any(c.get('mountpoint') or (c.get('name', '') in mounted)
                       for c in children):
                    continue
                try:
                    total = float(d.get('size') or 0)
                except Exception:
                    total = 0
                label = (d.get('model') or name).strip() or name
                result.append(('未挂载 ' + label, None, total, None))
        except Exception as e:
            log('unmounted usb: ' + str(e))
        return result

    def _models(self):
        result = {}
        try:
            out = subprocess.run(
                ['lsblk', '-J', '-b', '-o', 'NAME,TYPE,MODEL,PKNAME'],
                check=False, capture_output=True, text=True, timeout=5).stdout
            data = json.loads(out)

            def walk(devs):
                for d in devs or []:
                    yield d
                    yield from walk(d.get('children'))

            disks = {}
            for d in walk(data.get('blockdevices')):
                if d.get('type') == 'disk':
                    disks[d.get('name', '')] = (d.get('model') or '').strip()
            for d in walk(data.get('blockdevices')):
                if d.get('type') == 'part':
                    model = disks.get(d.get('pkname') or '', '')
                    if model:
                        result['/dev/%s' % d.get('name', '')] = model
        except Exception:
            pass
        return result

    def disks(self):
        seen = set()
        result = []
        info = self._disk_info()
        models = self._models()
        with open('/proc/mounts') as f:
            for line in f:
                parts = line.split()
                if len(parts) < 2:
                    continue
                src, mnt = parts[0], parts[1]
                real_src = os.path.realpath(src)
                if not real_src.startswith('/dev/') or real_src in seen:
                    continue
                if mnt.startswith('/boot'):
                    continue
                # 只显示本系统盘(/)和外接硬盘/U盘(USB, 含以后插入的),
                # 其它系统盘符(内置盘上的 Windows/Linux 分区)一律不显示
                if mnt not in ('/', '/persistent'):
                    if info is None:
                        continue
                    fstype, is_usb = info.get(real_src, info.get(src, ('', False)))
                    if not is_usb:
                        continue
                try:
                    s = os.statvfs(mnt)
                except OSError:
                    continue
                seen.add(real_src)
                total = s.f_frsize * s.f_blocks
                free = s.f_frsize * s.f_bavail
                used = total - free
                pct = 100.0 * used / total if total else 0
                base = os.path.basename(mnt)
                model = models.get(real_src, '')
                if mnt == '/':
                    label = 'C'
                elif mnt == '/persistent':
                    label = 'D'
                elif model in DISK_NAME_MAP:
                    label = DISK_NAME_MAP[model]
                elif base in DISK_NAME_MAP:
                    label = DISK_NAME_MAP[base]
                elif len(base) >= 12 and re.match(r'^[0-9A-Fa-f-]+$', base):
                    label = model or base
                else:
                    label = {'ORICO-1TB': 'O-1T',
                             'USB-231G': 'U-231G',
                             'Seagate-2T': 'S-2T'}.get(base, base)
                result.append((label, used, total, pct))
        return result


class MonitorWindow(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        visual = self.get_screen().get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)
        self.cfg = load_config()
        self.set_keep_below(True)
        self.set_type_hint(Gdk.WindowTypeHint.UTILITY)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_app_paintable(True)
        self.set_decorated(False)
        self.set_accept_focus(False)
        self.set_can_focus(False)

        self.mon = SystemMonitor()
        self._fit_size = None

        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.box.set_halign(Gtk.Align.CENTER)
        self.lbl = Gtk.Label()
        self.lbl.set_halign(Gtk.Align.CENTER)
        self.lbl.set_xalign(0.5)
        self.lbl.set_line_wrap(False)
        self.box.pack_start(self.lbl, False, False, 0)
        self.seg_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        self.box.pack_start(self.seg_box, False, False, 0)
        self.seg_rows = []
        self._seg_hist = {}
        try:
            sh = self.cfg.get('seg_hist') or {}
            fs = str(self.cfg.get('font_size', BASE_FONT_SIZE))
            if isinstance(sh, dict) and sh:
                if fs in sh and isinstance(sh[fs], dict):
                    self._seg_hist = {int(k): v for k, v in sh[fs].items()
                                      if str(k).isdigit()}
                else:
                    self._seg_hist = {int(k): v for k, v in sh.items()
                                      if str(k).isdigit()}
        except Exception:
            self._seg_hist = {}
        self.grid = Gtk.Grid()
        self.grid.set_row_spacing(2)
        self.grid.set_column_spacing(12)
        self.box.pack_start(self.grid, False, False, 0)
        self.multi_rows = []
        self.add(self.box)

        self.apply_style()
        self.add_events(Gdk.EventMask.SCROLL_MASK)
        self.connect('draw', self.on_draw)
        self.connect('button-press-event', self.on_button_press)
        self.connect('motion-notify-event', self.on_motion)
        self.connect('button-release-event', self.on_button_release)
        self.connect('scroll-event', self.on_scroll)

        self.dragging = False
        self.drag_start = None
        self.drag_orig = None

        GLib.timeout_add_seconds(1, self.tick)
        self.update()
        if self.cfg.get('x') is not None and self.cfg.get('y') is not None:
            self.move(self.cfg['x'], self.cfg['y'])
        self.show_all()
        self._apply_mode()
        if self.cfg.get('x') is None or self.cfg.get('y') is None:
            # 默认位置: 紧贴任务栏上方, 水平居中
            GLib.idle_add(self._place_default)
        elif self.cfg.get('center_h', True):
            GLib.idle_add(self._center_h)
        GLib.timeout_add(800, self._all_desktops)

    def _all_desktops(self):
        """固定到所有桌面: 进程内直接改 _NET_WM_DESKTOP(不再起子进程)"""
        if not getattr(self, '_ad_done', False):
            try:
                win = self.get_window()
                wid = win.get_xid() if win else 0
                if wid:
                    from Xlib import display as _xd
                    _d = _xd.Display()
                    _w = _d.create_resource_object('window', wid)
                    _w.change_property(_d.intern_atom('_NET_WM_DESKTOP'),
                                       _d.intern_atom('CARDINAL'), 32,
                                       [0xFFFFFFFF])
                    _d.sync()
                    _d.close()
                    self._ad_done = True
            except Exception:
                pass
        return False

    def apply_style(self):
        font = self.cfg.get('font', DEFAULT_FONT)
        size = int(self.cfg.get('font_size', BASE_FONT_SIZE))
        self.lbl.modify_font(Pango.FontDescription('%s %d' % (font, size)))
        for nl, vl in self.seg_rows:
            nl.modify_font(Pango.FontDescription('%s %d' % (font, size)))
            vl.modify_font(Pango.FontDescription('%s %d' % (font, size)))
        for nl, vl in self.multi_rows:
            nl.modify_font(Pango.FontDescription('%s %d' % (font, size)))
            vl.modify_font(Pango.FontDescription('%s %d' % (font, size)))
        self._size = size

    def _apply_mode(self):
        ml = bool(self.cfg.get('multi_line', False))
        self.lbl.set_visible(False)
        self.seg_box.set_visible(not ml)
        self.grid.set_visible(ml)
        self.set_size_request(-1, -1)
        GLib.idle_add(self._refit_size)
        GLib.idle_add(self._dock_and_center)
        self.snap_if_overlapping()

    def _refit_size(self):
        """切换模式后让窗口重新适应内容尺寸(否则宽度残留, 右缘贴屏导致拖不动)"""
        try:
            min_size, nat = self.get_preferred_size()
            self.resize(nat.width, nat.height)
        except Exception as e:
            log('refit: ' + str(e))
        return False

    def _dock_and_center(self):
        if self.dragging:
            return False
        try:
            screen_width = self.get_screen().get_width()
            window_width, window_height = self.get_size()
            x = max(0, (screen_width - window_width) // 2)
            taskbar_top = self._taskbar_top()
            if taskbar_top is not None:
                y = max(0, taskbar_top - 2 - window_height)
            else:
                y = self.get_position()[1]
            if (x, y) != self.get_position():
                self.move(x, y)
        except Exception as e:
            log('dock: ' + str(e))
        return False

    def _set_segs(self, segs):
        while len(self.seg_rows) < len(segs):
            nl = Gtk.Label()
            nl.set_halign(Gtk.Align.START)
            nl.set_xalign(0.0)
            vl = Gtk.Label()
            vl.set_halign(Gtk.Align.START)
            vl.set_xalign(0.0)
            seg = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
            seg.pack_start(nl, False, False, 0)
            seg.pack_start(vl, False, False, 0)
            self.seg_box.pack_start(seg, False, False, 0)
            self.seg_rows.append((nl, vl))
        for i in range(len(segs), len(self.seg_rows)):
            self.seg_rows[i][0].set_visible(False)
            self.seg_rows[i][1].set_visible(False)
        font = self.cfg.get('font', DEFAULT_FONT)
        font_desc = Pango.FontDescription('%s %d' % (font, self._size))
        total = 0
        for i, (lab, val) in enumerate(segs):
            nl, vl = self.seg_rows[i]
            nl.set_visible(True)
            vl.set_visible(True)
            nl.set_markup(lab)
            vl.set_markup(val)
            plain = re.sub(r'<[^>]+>', '', val)
            layout = self.create_pango_layout(plain)
            layout.set_font_description(font_desc)
            value_width = layout.get_pixel_size()[0]
            tgt = max(self._seg_hist.get(i, 0), value_width)
            self._seg_hist[i] = tgt
            vl.set_size_request(tgt, -1)
            label_layout = self.create_pango_layout(re.sub(r'<[^>]+>', '', lab))
            label_layout.set_font_description(font_desc)
            label_width = label_layout.get_pixel_size()[0]
            total += label_width + tgt
        total += 2 * max(0, len(segs) - 1) + 12
        self.set_size_request(total, -1)

    def _ensure_rows(self, n):
        created = False
        while len(self.multi_rows) < n:
            name_lbl = Gtk.Label()
            name_lbl.set_halign(Gtk.Align.START)
            name_lbl.set_xalign(0.0)
            val_lbl = Gtk.Label()
            val_lbl.set_halign(Gtk.Align.END)
            val_lbl.set_xalign(1.0)
            r = len(self.multi_rows)
            self.grid.attach(name_lbl, 0, r, 1, 1)
            self.grid.attach(val_lbl, 1, r, 1, 1)
            self.multi_rows.append((name_lbl, val_lbl))
            created = True
        if created:
            self.apply_style()
        for i, (nl, vl) in enumerate(self.multi_rows):
            visible = i < n
            nl.set_visible(visible)
            vl.set_visible(visible)

    def on_draw(self, widget, cr):
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        return False

    def _watch_source(self):
        path = os.path.abspath(__file__)
        try:
            mtime = os.path.getmtime(path)
        except Exception:
            return
        if getattr(self, '_src_mtime', None) is None:
            self._src_mtime = mtime
        elif mtime != self._src_mtime:
            os.execv(sys.executable, [sys.executable, path])

    def tick(self):
        self._watch_source()
        self.update()
        self._dock_and_center()
        GLib.timeout_add(150, self._dock_and_center)
        return True

    def esc(self, s):
        return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

    def update(self):
        lc = self.cfg.get('label_color', LABEL_COLOR)
        vc = self.cfg.get('value_color', VALUE_COLOR)
        wh = WHITE
        cpu = self.mon.cpu_pct()
        used, total, mpct = self.mon.mem()
        rx, tx = self.mon.net_speed()
        disks = self.mon.disks()
        disk_spans = []
        for lab, du, dt, dp in disks:
            lab_col = DISK_LABEL_COLORS.get(lab, lc)
            if du is None:
                disk_spans.append(
                    '<span foreground="%s">%s</span>'
                    '<span foreground="%s"> %s</span>'
                    % (lab_col, self.esc(lab), vc, self.esc(human(dt))))
                continue
            disk_spans.append(
                '<span foreground="%s">%s</span>'
                '<span foreground="%s"> %s/</span>'
                '<span foreground="%s">%s</span>'
                '<span foreground="%s"> (%d%%)</span>'
                % (lab_col, self.esc(lab), vc,
                   self.esc(human(du)), wh,
                   self.esc(human(dt)), vc, dp))
        if self.cfg.get('multi_line', False):
            self.update_multi(lc, vc, wh, cpu, used, total, mpct, rx, tx, disks)
            return
        self._last_disks = disks
        signature = tuple(item[0] for item in disks)
        if signature != getattr(self, '_disk_signature', None):
            self._disk_signature = signature
            self._seg_hist = {}
        segs = [
            ('<span foreground="%s">CPU：</span>' % lc,
             '<span foreground="%s">%.1f%%</span>' % (vc, cpu)),
            ('<span foreground="%s">内存：</span>' % lc,
             '<span foreground="%s">%s/</span>'
             '<span foreground="%s">%s</span>'
             '<span foreground="%s"> (%d%%)</span>'
             % (vc, self.esc(human(used)), wh,
                self.esc(human(total)), vc, mpct)),
            ('<span foreground="%s">硬盘：</span>' % lc,
             ' | '.join(disk_spans)),
            ('<span foreground="%s">网速：</span>' % lc,
             '<span foreground="%s">↑ %s/s</span>'
             '<span foreground="%s">   </span>'
             '<span foreground="%s">↓ %s/s</span>'
             % (vc, self.esc(human(tx)), vc, wh, self.esc(human(rx)))),
        ]
        self._set_segs(segs)
        self.apply_style()
        GLib.idle_add(self._dock_and_center)

    def update_multi(self, lc, vc, wh, cpu, used, total, mpct, rx, tx, disks):
        rows = [
            ('CPU',
             '<span foreground="%s">%.1f%%</span>' % (vc, cpu)),
            ('内存',
             '<span foreground="%s">%s/</span>'
             '<span foreground="%s">%s</span>'
             '<span foreground="%s"> (%d%%)</span>'
             % (vc, self.esc(human(used)), wh,
                self.esc(human(total)), vc, mpct)),
        ]
        for lab, du, dt, dp in disks:
            lab_col = DISK_LABEL_COLORS.get(lab, lc)
            if du is None:
                rows.append((lab, '<span foreground="%s">%s</span>'
                                  % (vc, self.esc(human(dt)))))
                continue
            rows.append((lab,
                         '<span foreground="%s">%s/</span>'
                         '<span foreground="%s">%s</span>'
                         '<span foreground="%s"> (%d%%)</span>'
                         % (vc, self.esc(human(du)), wh,
                            self.esc(human(dt)), vc, dp)))
        rows.append(('网速',
                     '<span foreground="%s">↑ %s/s</span>'
                     '<span foreground="%s">   </span>'
                     '<span foreground="%s">↓ %s/s</span>'
                     % (vc, self.esc(human(tx)), wh, wh, self.esc(human(rx)))))
        self._ensure_rows(len(rows))
        for i, (name, val) in enumerate(rows):
            nl, vl = self.multi_rows[i]
            nl.set_markup('<span foreground="%s">%s</span>' % (lc, self.esc(name)))
            vl.set_markup(val)
        self.apply_style()

    def on_button_press(self, widget, event):
        if self.cfg.get('lock_position', False):
            if event.button == 3:
                self.show_menu(event)
            return True
        if event.button == 1:
            self.dragging = True
            self.drag_start = (event.x_root, event.y_root)
            self.drag_orig = self.get_position()
            return True
        if event.button == 3:
            self.show_menu(event)
            return True
        return False

    def on_motion(self, widget, event):
        if self.dragging:
            nx = self.drag_orig[0] + event.x_root - self.drag_start[0]
            ny = self.drag_orig[1] + event.y_root - self.drag_start[1]
            lim = self._y_limit()
            if lim is not None:
                ny = min(ny, lim)
            self.move(nx, ny)
            self._unstick()
            return True
        return False

    def _unstick(self):
        """拖动时窗口管理器可能贴边拉伸窗口(deepin), 持续拉回自然尺寸"""
        try:
            _, nat = self.get_preferred_size()
            cw, ch = self.get_size()
            if cw != nat.width or ch != nat.height:
                self.resize(nat.width, nat.height)
        except Exception:
            pass

    def _center_h(self, retry=3):
        """水平居中(左右对称), 需等布局完成后调用"""
        try:
            sw = self.get_screen().get_width()
            cw, ch = self.get_size()
            x, y = self.get_position()
            y = self.cfg.get('y', y)
            nx = max(0, (sw - cw) // 2)
            self.move(nx, y)
            self.cfg['x'] = nx
            self.cfg['y'] = y
            self.cfg['center_h'] = True
            self.save_config()
        except Exception as e:
            log('center: ' + str(e))
        if retry > 0:
            GLib.timeout_add(300, lambda: self._center_h(retry - 1))
        return False

    def _place_default(self, retry=10):
        """默认位置: 紧贴任务栏上方, 水平居中"""
        try:
            if retry <= 0:
                return False
            cw, ch = self.get_size()
            if cw <= 1 or ch <= 1:
                GLib.timeout_add(200, lambda: self._place_default(retry - 1))
                return False
            sw = self.get_screen().get_width()
            tb = self._taskbar_top()
            if tb is not None:
                y = max(0, tb - 2 - ch)
            else:
                sh = self.get_screen().get_height()
                y = max(0, sh - ch - 60)
            x = max(0, (sw - cw) // 2)
            self.move(x, y)
            self.cfg['x'], self.cfg['y'] = x, y
            self.cfg['center_h'] = True
            self.save_config()
            log('place default: %d,%d (taskbar_top=%s)' % (x, y, tb))
        except Exception as e:
            log('place default: ' + str(e))
        return False

    def _taskbar_top(self):
        """检测屏幕底部任务栏的顶边位置, 无任务栏返回 None"""
        try:
            sh = self.get_screen().get_height()
            out = subprocess.check_output(['xwininfo', '-root', '-tree'],
                                          stderr=subprocess.DEVNULL, text=True)
            for line in out.splitlines():
                m = re.search(r'([0-9]+)x([0-9]+)\+([0-9]+)\+([0-9]+)', line)
                if not m:
                    continue
                w, h, x, y = (int(v) for v in m.groups())
                if (w >= 3000 and x == 0 and y > 0
                        and y + h >= sh - 5 and h < 300):
                    return y
        except Exception as e:
            log('taskbar detect: ' + str(e))
        return None

    def _y_limit(self):
        """窗口 y 的最大值: 底边紧贴任务栏避让边界(系统允许的极限)"""
        tb = self._taskbar_top()
        if tb is None:
            return None
        ww, wh = self.get_size()
        return tb - 2 - wh

    def snap_if_overlapping(self):
        """若窗口底边越过任务栏避让边界, 自动贴到系统允许的极限位置"""
        try:
            lim = self._y_limit()
            if lim is None:
                return
            x, y = self.get_position()
            if y > lim:
                self.move(x, max(0, lim))
        except Exception:
            pass

    def on_button_release(self, widget, event):
        if event.button == 1:
            self.dragging = False
            self._unstick()
            self.snap_if_overlapping()
            x, y = self.get_position()
            self.cfg['x'], self.cfg['y'] = x, y
            self.cfg['center_h'] = False
            self.save_config()
        return False

    def on_scroll(self, widget, event):
        if event.direction == Gdk.ScrollDirection.UP:
            self.resize_by(2)
        elif event.direction == Gdk.ScrollDirection.DOWN:
            self.resize_by(-2)
        return True

    def _autostart_desktop_name(self):
        return os.path.basename(sys.argv[0]).replace('.py', '')

    def _autostart_enabled(self):
        name = self._autostart_desktop_name()
        path = os.path.expanduser(f'~/.config/autostart/{{name}}.desktop')
        return os.path.exists(path)

    def _toggle_autostart(self, enable):
        name = self._autostart_desktop_name()
        autostart_dir = os.path.expanduser('~/.config/autostart')
        desktop_path = os.path.join(autostart_dir, f'{{name}}.desktop')
        if enable:
            os.makedirs(autostart_dir, exist_ok=True)
            with open(desktop_path, 'w') as f:
                f.write('[Desktop Entry]\n')
                f.write('Type=Application\n')
                f.write(f'Name={{name}}\n')
                if sys.argv[0].endswith('.py'):
                    f.write(f'Exec=python3 {os.path.abspath(sys.argv[0])}\n')
                else:
                    f.write(f'Exec={os.path.abspath(sys.argv[0])}\n')
                f.write('X-GNOME-Autostart-enabled=true\n')
                f.write('NoDisplay=true\n')
        else:
            if os.path.exists(desktop_path):
                os.remove(desktop_path)

    def show_menu(self, event):
        menu = Gtk.Menu()

        def add(label, cb):
            item = Gtk.MenuItem(label=label)
            item.connect('activate', cb)
            menu.append(item)
        add('增大字号', lambda w: self.resize_by(2))
        add('减小字号', lambda w: self.resize_by(-2))
        add('水平居中', lambda w: self._center_h())
        lock_item = Gtk.CheckMenuItem(label='锁定位置')
        lock_item.set_active(bool(self.cfg.get('lock_position', False)))
        lock_item.connect('toggled', self.on_lock_toggle)
        menu.append(lock_item)
        ml_item = Gtk.CheckMenuItem(label='多行显示')
        ml_item.set_active(bool(self.cfg.get('multi_line', False)))
        ml_item.connect('toggled', self.on_multi_toggle)
        menu.append(ml_item)
        menu.append(Gtk.SeparatorMenuItem())
        for name, col in (('黄色', '#FFEB3B'), ('天蓝色', '#87CEEB'), ('橙色', '#FFA726'),
                          ('红色', '#FF5252'), ('绿色', '#69F0AE'), ('白色', '#FFFFFF')):
            add(name, lambda w, c=col: self.set_color(c))
        
        autostart_item = Gtk.CheckMenuItem(label='开机自启')
        autostart_item.set_active(self._autostart_enabled())
        autostart_item.connect('toggled', lambda w: self._toggle_autostart(w.get_active()))
        menu.append(autostart_item)

        menu.append(Gtk.SeparatorMenuItem())
        add('退出', lambda w: Gtk.main_quit())
        menu.show_all()
        menu.popup(None, None, None, None, event.button, event.time)

    def on_lock_toggle(self, item):
        self.cfg['lock_position'] = item.get_active()
        if item.get_active():
            x, y = self.get_position()
            self.cfg['x'], self.cfg['y'] = x, y
        self.save_config()

    def on_multi_toggle(self, item):
        self.cfg['multi_line'] = item.get_active()
        self._apply_mode()
        self.update()
        self.save_config()

    def resize_by(self, delta):
        self.cfg['font_size'] = max(10, min(96, int(self.cfg.get('font_size', BASE_FONT_SIZE)) + delta))
        self.apply_style()
        self.update()
        self._dock_and_center()
        self.save_config()

    def set_color(self, color):
        self.cfg['label_color'] = color
        self.save_config()
        self.update()

    def save_config(self):
        try:
            os.makedirs(USER_DIR, exist_ok=True)
            with open(CONFIG_PATH, 'w') as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=2)
        except Exception as e:
            log('config save: ' + str(e))


def main():
    log('monitor start')
    win = MonitorWindow()
    Gtk.main()


if __name__ == '__main__':
    main()
